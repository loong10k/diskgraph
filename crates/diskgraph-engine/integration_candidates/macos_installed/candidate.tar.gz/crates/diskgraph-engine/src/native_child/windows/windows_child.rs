//! Win10+ 原生 CreateProcessW：进程在运行前即绑定本任务 Job。

use std::io;
use std::process::Command;
use std::ptr::{null, null_mut};
use std::time::{Duration, Instant};
#[cfg(test)]
use windows_sys::Win32::Foundation::{DUPLICATE_SAME_ACCESS, DuplicateHandle};
use windows_sys::Win32::Foundation::{HANDLE, WAIT_OBJECT_0, WAIT_TIMEOUT};
#[cfg(test)]
use windows_sys::Win32::System::IO::OVERLAPPED;
use windows_sys::Win32::System::JobObjects::{
    CreateJobObjectW, JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE, JOBOBJECT_BASIC_ACCOUNTING_INFORMATION,
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION, JobObjectBasicAccountingInformation,
    JobObjectExtendedLimitInformation, QueryInformationJobObject, SetInformationJobObject,
    TerminateJobObject,
};
#[cfg(test)]
use windows_sys::Win32::System::Threading::GetCurrentProcess;
use windows_sys::Win32::System::Threading::{
    CREATE_NO_WINDOW, CREATE_SUSPENDED, CREATE_UNICODE_ENVIRONMENT, CreateProcessW,
    EXTENDED_STARTUPINFO_PRESENT, GetExitCodeProcess, INFINITE, PROCESS_INFORMATION, ResumeThread,
    STARTF_USESTDHANDLES, STARTUPINFOEXW, WaitForSingleObject,
};

use super::super::{ChildError, ChildInputMode, ChildSpawnError, ControlWriteStatus};
use super::attribute_list::AttributeList;
use super::overlapped_control_pipe::OverlappedControlPipe;
use super::overlapped_pipe::OverlappedPipe;
use super::owned_handle::OwnedHandle;
use super::pipe_security::PipeSecurity;
use super::windows_command_line::WindowsCommandLine;
#[cfg(test)]
use super::windows_control_test_witness::WindowsControlTestWitness;
use super::windows_normal_exit::WindowsNormalExit;

/// 本次 Windows 子进程的唯一 Job、leader、两条读管道与可选控制输入。来源：Win32 CreateProcessW、Job Objects 与 Overlapped I/O。
pub(crate) struct WindowsChild {
    job: Option<OwnedHandle>,
    process: Option<OwnedHandle>,
    stdout: OverlappedPipe,
    stderr: OverlappedPipe,
    control: Option<OverlappedControlPipe>,
    normal_exit: WindowsNormalExit,
    exit: Option<i32>,
    cleaned: bool,
}

impl WindowsChild {
    /// 创建被独立 Job 原子约束的 suspended 子进程。
    /// 参数：command 是显式环境命令，checkpoint 借用原调用方检查。返回：受 Job 约束的子进程所有权或失败。
    pub(crate) fn spawn<E>(
        command: &mut Command,
        checkpoint: impl FnMut() -> Result<(), E>,
    ) -> Result<Self, ChildSpawnError<E>> {
        Self::spawn_with_input(command, ChildInputMode::Null, checkpoint)
    }

    /// 以显式 stdin 模式创建同一个 Job 约束的子进程，不建立新期限。
    /// 参数：command 是原显式命令，mode 为 Null 或 WorkerControl，checkpoint 借用原授权与期限。返回：唯一子进程 owner 或原检查点／OS 错误。
    pub(crate) fn spawn_with_input<E>(
        command: &mut Command,
        mode: ChildInputMode,
        mut checkpoint: impl FnMut() -> Result<(), E>,
    ) -> Result<Self, ChildSpawnError<E>> {
        checkpoint().map_err(ChildSpawnError::checkpoint)?;
        let mut input = WindowsCommandLine::from_command(command)?;
        let security = PipeSecurity::for_current_user()?;
        let nonce = uuid::Uuid::new_v4();
        let stdout_name = pipe_name(&format!("diskgraph-probe-{nonce}-out"));
        let stderr_name = pipe_name(&format!("diskgraph-probe-{nonce}-err"));
        let (stdout, stdout_writer) = OverlappedPipe::create(&stdout_name, &security)?;
        let (stderr, stderr_writer) = OverlappedPipe::create(&stderr_name, &security)?;
        let (control, stdin) =
            OverlappedControlPipe::prepare_input(mode, &nonce, &security, &mut checkpoint)?;
        let job = OwnedHandle::from_raw(
            unsafe { CreateJobObjectW(null(), null()) },
            "CreateJobObjectW",
        )?;
        let mut limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION::default();
        limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        if unsafe {
            SetInformationJobObject(
                job.as_raw(),
                JobObjectExtendedLimitInformation,
                (&raw const limits).cast(),
                std::mem::size_of_val(&limits) as u32,
            )
        } == 0
        {
            return Err(last("SetInformationJobObject(KILL_ON_JOB_CLOSE)").into());
        }
        let mut attributes = AttributeList::new()?;
        let handles: [HANDLE; 3] = [
            stdin.as_raw(),
            stdout_writer.as_raw(),
            stderr_writer.as_raw(),
        ];
        attributes.set_jobs([job.as_raw()])?;
        attributes.set_handles(handles)?;
        let mut startup = STARTUPINFOEXW::default();
        startup.StartupInfo.cb = std::mem::size_of::<STARTUPINFOEXW>() as u32;
        startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
        startup.StartupInfo.hStdInput = handles[0];
        startup.StartupInfo.hStdOutput = handles[1];
        startup.StartupInfo.hStdError = handles[2];
        startup.lpAttributeList = attributes.as_raw();
        let mut info = PROCESS_INFORMATION::default();
        checkpoint().map_err(ChildSpawnError::checkpoint)?;
        let application = input.application();
        let arguments = input.arguments();
        let environment = input.environment();
        let directory = input.directory();
        if unsafe {
            CreateProcessW(
                application,
                arguments,
                null(),
                null(),
                1,
                CREATE_SUSPENDED
                    | CREATE_NO_WINDOW
                    | CREATE_UNICODE_ENVIRONMENT
                    | EXTENDED_STARTUPINFO_PRESENT,
                environment,
                directory,
                &startup.StartupInfo,
                &mut info,
            )
        } == 0
        {
            return Err(last("CreateProcessW(JOB_LIST,HANDLE_LIST)").into());
        }
        let process = OwnedHandle::from_raw(info.hProcess, "CreateProcessW(process handle)")?;
        let thread = OwnedHandle::from_raw(info.hThread, "CreateProcessW(thread handle)")?;
        let mut child = Self {
            job: Some(job),
            process: Some(process),
            stdout,
            stderr,
            control,
            normal_exit: WindowsNormalExit::new(),
            exit: None,
            cleaned: false,
        };
        // Child 已有且 suspended；父本地写端必须立即关闭，避免 EOF 被自身阻止。
        drop(stdin);
        drop(stdout_writer);
        drop(stderr_writer);
        #[cfg(test)]
        if let (Some(job), Some(process)) = (&child.job, &child.process) {
            WindowsControlTestWitness::record(job.as_raw(), process.as_raw());
        }
        #[cfg(test)]
        if command.get_envs().any(|(key, value)| {
            key.to_string_lossy()
                .eq_ignore_ascii_case("DG_WINDOWS_NATIVE_FAULT")
                && value.is_some_and(|value| value.to_string_lossy() == "post_create")
        }) {
            // 清理前释放本 owner 已完成的线程句柄，保持句柄生命周期明确。
            drop(thread);
            let error = ChildError::Unsupported("injected post-create failure");
            return Err(error.with_cleanup(child.cleanup()).into());
        }
        if let Err(error) = checkpoint() {
            drop(thread);
            return Err(ChildSpawnError::checkpoint(error).with_cleanup(child.cleanup()));
        }
        let previous = unsafe { ResumeThread(thread.as_raw()) };
        let resume_failure = if previous == u32::MAX {
            Some(last("ResumeThread"))
        } else if previous != 1 {
            Some(ChildError::Unsupported(
                "probe thread did not have exactly one suspend count",
            ))
        } else {
            None
        };
        drop(thread);
        if let Some(error) = resume_failure {
            return Err(error.with_cleanup(child.cleanup()).into());
        }
        if let Err(error) = checkpoint() {
            return Err(ChildSpawnError::checkpoint(error).with_cleanup(child.cleanup()));
        }
        Ok(child)
    }

    /// 发起单个固定大小控制块。参数：bytes 非空且最多 4096 字节。返回：Written、Pending 或原错；Null 模式明确不支持。
    pub(crate) fn start_control_write(
        &mut self,
        bytes: &[u8],
    ) -> Result<ControlWriteStatus, ChildError> {
        self.control
            .as_mut()
            .ok_or(ChildError::Unsupported("control input mode is Null"))?
            .start_write(bytes)
    }

    /// 只轮询当前自有控制块。参数：无。返回：真实完成字节数、Pending 或 Closed；不续期、不等待。
    pub(crate) fn poll_control_write(&mut self) -> Result<ControlWriteStatus, ChildError> {
        let result = self
            .control
            .as_mut()
            .ok_or(ChildError::Unsupported("control input mode is Null"))?
            .poll_write();
        self.normal_exit.record_control(&result);
        result
    }

    /// 封闭后续控制写入。参数：无。返回：Closed 或保留内核借用内存的 Pending，不保证帧已 flush。
    pub(crate) fn request_control_close(&mut self) -> Result<ControlWriteStatus, ChildError> {
        let result = self
            .control
            .as_mut()
            .ok_or(ChildError::Unsupported("control input mode is Null"))?
            .request_close();
        self.normal_exit.record_control(&result);
        result
    }

    /// 借用真正 pending 操作供原生测试核验。参数：无。返回：原写句柄、OVERLAPPED 和 buffer 地址，不注入状态。
    #[cfg(test)]
    pub(crate) fn control_io_witness_for_test(
        &self,
    ) -> Result<(HANDLE, *const OVERLAPPED, *const u8), ChildError> {
        self.control
            .as_ref()
            .ok_or(ChildError::Unsupported("control input mode is Null"))?
            .io_witness()
    }

    /// 借用父控制句柄供继承测试。参数：无。返回：原父写端与 event；不转移、不复制所有权。
    #[cfg(test)]
    pub(crate) fn control_handles_for_test(&self) -> Result<(HANDLE, HANDLE), ChildError> {
        self.control
            .as_ref()
            .ok_or(ChildError::Unsupported("control input mode is Null"))?
            .handles()
    }

    /// 观察 leader 是否已退出。参数：无。返回：true 表示已记录退出码，错误表示 Win32 查询失败。
    pub(crate) fn poll(&mut self) -> Result<bool, ChildError> {
        if self.exit.is_some() {
            return Ok(true);
        }
        let process = self
            .process
            .as_ref()
            .ok_or(ChildError::Unsupported("probe leader already cleaned"))?;
        match unsafe { WaitForSingleObject(process.as_raw(), 0) } {
            WAIT_TIMEOUT => Ok(false),
            WAIT_OBJECT_0 => {
                let mut code = 0u32;
                if unsafe { GetExitCodeProcess(process.as_raw(), &mut code) } == 0 {
                    return Err(last("GetExitCodeProcess"));
                }
                self.exit = Some(code as i32);
                Ok(true)
            }
            _ => Err(last("WaitForSingleObject(probe leader)")),
        }
    }

    /// 查询已记录的 leader 退出码。参数：无。返回：未观察退出时为 None，否则为进程退出码。
    pub(crate) fn exit_code(&self) -> Option<i32> {
        self.exit
    }

    /// 以原检查点观察正常整 Job 完成，不终止或清理。参数：checkpoint 为原期限／授权检查。返回：leader、双 EOF、控制 Closed 和 Job 活动零全部成立时 true；原检查点错误保留且不隐含 cleanup，原退出码不改写。
    pub(crate) fn poll_normal_exit<E>(
        &mut self,
        mut checkpoint: impl FnMut() -> Result<(), E>,
    ) -> Result<bool, ChildSpawnError<E>> {
        checkpoint().map_err(ChildSpawnError::checkpoint)?;
        if self.control.is_none() {
            return Err(ChildError::Unsupported("normal exit requires WorkerControl input").into());
        }
        let leader_exited = self.poll()?;
        let complete = self.normal_exit.poll(
            self.job.as_ref(),
            leader_exited,
            self.stdout.eof() && self.stderr.eof(),
        )?;
        checkpoint().map_err(ChildSpawnError::checkpoint)?;
        Ok(complete)
    }

    /// 非阻塞读取 stdout 的固定片段。参数：无。返回：有数据时为最多 4096 字节，否则为 None 或错误。
    pub(crate) fn read_stdout(&mut self) -> Result<Option<&[u8]>, ChildError> {
        self.stdout.read_next()
    }

    /// 非阻塞读取 stderr 的固定片段。参数：无。返回：有数据时为最多 4096 字节，否则为 None 或错误。
    pub(crate) fn read_stderr(&mut self) -> Result<Option<&[u8]>, ChildError> {
        self.stderr.read_next()
    }

    /// 查询 stdout 是否已确认 EOF。参数：无。返回：确认 EOF 时为 true。
    pub(crate) fn stdout_eof(&self) -> bool {
        self.stdout.eof()
    }

    /// 查询 stderr 是否已确认 EOF。参数：无。返回：确认 EOF 时为 true。
    pub(crate) fn stderr_eof(&self) -> bool {
        self.stderr.eof()
    }

    /// 为 Windows 原生验收复制本 Job 句柄，便于清理前后直接核验活动进程数。
    /// 参数：无。返回：测试独有的 Job 句柄所有权或 Win32 错误。
    #[cfg(test)]
    pub(crate) fn duplicate_job_for_test(&self) -> Result<OwnedHandle, ChildError> {
        let job = self
            .job
            .as_ref()
            .ok_or(ChildError::Unsupported("probe Job already cleaned"))?;
        duplicate_handle_for_test(job.as_raw(), "DuplicateHandle(test Job)")
    }

    /// 为 Windows 原生验收复制 leader 句柄，模拟外部宿主保持已退出进程引用。
    /// 参数：无。返回：测试独有的进程句柄所有权或 Win32 错误。
    #[cfg(test)]
    pub(crate) fn duplicate_leader_for_test(&self) -> Result<OwnedHandle, ChildError> {
        let process = self
            .process
            .as_ref()
            .ok_or(ChildError::Unsupported("probe leader already cleaned"))?;
        duplicate_handle_for_test(process.as_raw(), "DuplicateHandle(test leader)")
    }

    /// 清理本次 Job 与所有普通后代并回收 pending I/O。
    /// 参数：无。返回：Job 活动进程归零且管道回收成功，或可包含多项原因的清理错误。
    /// Job 归零只观察一秒；leader 等待与 pending I/O 安全回收仍可能超过协作期限。
    pub(crate) fn cleanup(&mut self) -> Result<(), ChildError> {
        if self.cleaned {
            return Ok(());
        }
        self.cleaned = true;
        let mut failure = None;
        let mut job = self.job.take();
        let terminated = if let Some(active_job) = job.as_ref() {
            if unsafe { TerminateJobObject(active_job.as_raw(), 1) } == 0 {
                record_failure(&mut failure, last("TerminateJobObject"));
                // 终止请求失败时先关闭 Job，触发 KILL_ON_JOB_CLOSE 后备。
                drop(job.take());
                false
            } else {
                true
            }
        } else {
            false
        };
        // 先等待并关闭本 owner 的 leader 句柄；Job 终态以随后实际查询为准。
        if let Some(process) = self.process.take() {
            if unsafe { WaitForSingleObject(process.as_raw(), INFINITE) } != WAIT_OBJECT_0 {
                record_failure(&mut failure, last("WaitForSingleObject(cleanup)"));
            }
            drop(process);
        }
        if terminated && let Some(active_job) = job.as_ref() {
            // TerminateJobObject 的返回不证明所有普通后代已退出。固定结构逐次查询；
            // 只在有限观察期内等待，避免无法确认 Job 终态时无限循环。
            let observed = observe_job_empty(Duration::from_secs(1), || {
                let mut accounting = JOBOBJECT_BASIC_ACCOUNTING_INFORMATION::default();
                if unsafe {
                    QueryInformationJobObject(
                        active_job.as_raw(),
                        JobObjectBasicAccountingInformation,
                        (&raw mut accounting).cast(),
                        std::mem::size_of_val(&accounting) as u32,
                        null_mut(),
                    )
                } == 0
                {
                    return Err(last("QueryInformationJobObject(cleanup)"));
                }
                Ok(accounting.ActiveProcesses)
            });
            if let Err(error) = observed {
                record_failure(&mut failure, error);
            }
        }
        // 查询失败时仍关闭 Job 触发后备终止，但明确返回不完整清理错误。
        drop(job);
        if let Err(error) = self.stdout.cancel_pending() {
            record_failure(&mut failure, error);
        }
        if let Err(error) = self.stderr.cancel_pending() {
            record_failure(&mut failure, error);
        }
        if let Some(control) = self.control.as_mut()
            && let Err(error) = control.cleanup()
        {
            record_failure(&mut failure, error);
        }
        failure.map_or(Ok(()), Err)
    }
}

impl Drop for WindowsChild {
    fn drop(&mut self) {
        let _ = self.cleanup();
    }
}

fn pipe_name(name: &str) -> Vec<u16> {
    format!(r"\\.\pipe\{name}")
        .encode_utf16()
        .chain(std::iter::once(0))
        .collect()
}

fn last(context: &'static str) -> ChildError {
    ChildError::io(context, io::Error::last_os_error())
}

fn record_failure(current: &mut Option<ChildError>, error: ChildError) {
    *current = Some(match current.take() {
        Some(primary) => primary.with_cleanup(Err(error)),
        None => error,
    });
}

fn observe_job_empty<F>(limit: Duration, mut active_processes: F) -> Result<(), ChildError>
where
    F: FnMut() -> Result<u32, ChildError>,
{
    let observed_at = Instant::now();
    loop {
        if active_processes()? == 0 {
            return Ok(());
        }
        if observed_at.elapsed() >= limit {
            return Err(ChildError::Io(format!(
                "QueryInformationJobObject(cleanup): ActiveProcesses remained nonzero after {} ms",
                limit.as_millis()
            )));
        }
        std::thread::sleep(Duration::from_millis(5));
    }
}

#[cfg(test)]
fn duplicate_handle_for_test(
    raw: HANDLE,
    context: &'static str,
) -> Result<OwnedHandle, ChildError> {
    let process = unsafe { GetCurrentProcess() };
    let mut copy = null_mut();
    if unsafe {
        DuplicateHandle(
            process,
            raw,
            process,
            &mut copy,
            0,
            0,
            DUPLICATE_SAME_ACCESS,
        )
    } == 0
    {
        return Err(last(context));
    }
    OwnedHandle::from_raw(copy, context)
}

#[cfg(test)]
mod tests {
    use super::observe_job_empty;
    use crate::native_child::ChildError;
    use std::time::{Duration, Instant};

    #[test]
    fn injected_nonzero_accounting_stops_at_observation_limit() {
        let started = Instant::now();
        let error = observe_job_empty(Duration::from_millis(25), || Ok(1)).unwrap_err();
        assert!(
            matches!(error, ChildError::Io(message) if message.contains("ActiveProcesses remained nonzero"))
        );
        assert!(started.elapsed() >= Duration::from_millis(25));
        assert!(started.elapsed() < Duration::from_secs(2));
    }

    #[test]
    fn injected_accounting_query_error_fails_without_retrying_as_success() {
        let error = observe_job_empty(Duration::from_secs(1), || {
            Err(ChildError::Io("injected accounting failure".to_owned()))
        })
        .unwrap_err();
        assert!(
            matches!(error, ChildError::Io(message) if message == "injected accounting failure")
        );
    }
}
