//! 独占控制输入写管道；业务轮询不等待，安全清理保留内核借用的稳定内存直到完成。

use std::io;
use std::ptr::{null, null_mut};
use std::time::Duration;
use windows_sys::Win32::Foundation::{
    ERROR_IO_INCOMPLETE, ERROR_IO_PENDING, ERROR_NOT_FOUND, ERROR_OPERATION_ABORTED,
    ERROR_PIPE_CONNECTED, GENERIC_READ, GetLastError, HANDLE, STATUS_PENDING,
};
use windows_sys::Win32::Storage::FileSystem::{
    CreateFileW, FILE_ATTRIBUTE_NORMAL, FILE_FLAG_FIRST_PIPE_INSTANCE, FILE_FLAG_OVERLAPPED,
    FILE_SHARE_READ, FILE_SHARE_WRITE, OPEN_EXISTING, PIPE_ACCESS_OUTBOUND, WriteFile,
};
use windows_sys::Win32::System::IO::{CancelIoEx, GetOverlappedResult, OVERLAPPED};
use windows_sys::Win32::System::Pipes::{
    ConnectNamedPipe, CreateNamedPipeW, PIPE_READMODE_BYTE, PIPE_REJECT_REMOTE_CLIENTS,
    PIPE_TYPE_BYTE, PIPE_WAIT,
};
use windows_sys::Win32::System::Threading::{CreateEventW, ResetEvent};

use super::super::{ChildError, ChildInputMode, ChildSpawnError, ControlWriteStatus};
use super::owned_handle::OwnedHandle;
use super::pipe_security::PipeSecurity;

/// 父进程唯一控制写端与一块稳定内存。来源：Win32 outbound named pipe、OVERLAPPED 和 CancelIoEx 完成契约。
pub(super) struct OverlappedControlPipe {
    write: Option<OwnedHandle>,
    event: OwnedHandle,
    operation: Box<OVERLAPPED>,
    bytes: Box<[u8; ControlWriteStatus::MAX_CHUNK_BYTES]>,
    length: usize,
    pending: bool,
    connecting: bool,
    closing: bool,
    cancel_requested: bool,
    cancel_accepted: bool,
}

impl OverlappedControlPipe {
    /// 准备原 NUL 或显式控制 stdin。参数：mode 为输入模式，nonce 为本次随机名称，security 为原 DACL，checkpoint 借用原期限。返回：父控制 owner 与唯一可继承子读端，或保留原检查点错误。
    pub(super) fn prepare_input<E>(
        mode: ChildInputMode,
        nonce: &uuid::Uuid,
        security: &PipeSecurity,
        checkpoint: &mut impl FnMut() -> Result<(), E>,
    ) -> Result<(Option<Self>, OwnedHandle), ChildSpawnError<E>> {
        if mode == ChildInputMode::Null {
            // 保留原 NUL 句柄的属性、访问标志、错误文本和启动阶段，不新增检查点。
            let mut inheritable = security.attributes(true);
            inheritable.lpSecurityDescriptor = null_mut();
            let nul: Vec<u16> = r"\\.\NUL"
                .encode_utf16()
                .chain(std::iter::once(0))
                .collect();
            let stdin = OwnedHandle::from_raw(
                unsafe {
                    CreateFileW(
                        nul.as_ptr(),
                        GENERIC_READ,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        &inheritable,
                        OPEN_EXISTING,
                        FILE_ATTRIBUTE_NORMAL,
                        null_mut(),
                    )
                },
                "CreateFileW(NUL stdin)",
            )?;
            return Ok((None, stdin));
        }
        let name: Vec<u16> = format!(r"\\.\pipe\diskgraph-control-{nonce}-in")
            .encode_utf16()
            .chain(std::iter::once(0))
            .collect();
        Self::create(&name, security, checkpoint).map(|(pipe, stdin)| (Some(pipe), stdin))
    }

    /// 写入一个自有数据块，禁止覆盖未完成块。参数：source 非空且最多 4096 字节。返回：真实内核完成字节数、Pending 或原 I/O 错误；不证明 worker 已读取。
    pub(super) fn start_write(&mut self, source: &[u8]) -> Result<ControlWriteStatus, ChildError> {
        if self.closing || self.write.is_none() {
            return Err(ChildError::Unsupported(
                "control input already closing or closed",
            ));
        }
        if self.pending {
            return Err(ChildError::Unsupported("control write already pending"));
        }
        if source.is_empty() || source.len() > self.bytes.len() {
            return Err(ChildError::Unsupported(
                "control write requires 1..=4096 bytes",
            ));
        }
        if unsafe { ResetEvent(self.event.as_raw()) } == 0 {
            return Err(last("ResetEvent(control write)"));
        }
        *self.operation = OVERLAPPED::default();
        self.operation.hEvent = self.event.as_raw();
        self.bytes[..source.len()].copy_from_slice(source);
        self.length = source.len();
        self.cancel_requested = false;
        self.cancel_accepted = false;
        self.pending = true;
        let started = unsafe {
            WriteFile(
                self.handle()?,
                self.bytes.as_ptr(),
                self.length as u32,
                null_mut(),
                self.operation.as_mut(),
            )
        };
        let error = if started == 0 {
            unsafe { GetLastError() }
        } else {
            0
        };
        if started != 0 {
            return self.finish_io(false);
        }
        if error == ERROR_IO_PENDING {
            Ok(ControlWriteStatus::Pending)
        } else {
            self.pending = false;
            self.length = 0;
            Err(os_error("WriteFile(control input)", error))
        }
    }

    /// 只查询同一个未完成写入。参数：无。返回：Pending、一次真实 Written 或 Closed；空闲轮询被拒绝。
    pub(super) fn poll_write(&mut self) -> Result<ControlWriteStatus, ChildError> {
        if self.pending {
            self.finish_io(false)
        } else if self.write.is_none() {
            Ok(ControlWriteStatus::Closed)
        } else {
            Err(ChildError::Unsupported("no pending control write"))
        }
    }

    /// 封闭后续写入并只请求一次取消。参数：无。返回：Closed 或仍持有内核借用内存的 Pending；正常完成竞争由随后 poll 返回 Written 一次。
    pub(super) fn request_close(&mut self) -> Result<ControlWriteStatus, ChildError> {
        self.closing = true;
        if !self.pending {
            self.write.take();
            return Ok(ControlWriteStatus::Closed);
        }
        if !self.cancel_requested {
            self.cancel_requested = true;
            let cancelled = unsafe { CancelIoEx(self.handle()?, self.operation.as_ref()) };
            let error = if cancelled == 0 {
                unsafe { GetLastError() }
            } else {
                0
            };
            self.cancel_accepted = cancelled != 0;
            if cancelled == 0 && error != ERROR_NOT_FOUND {
                return Err(os_error("CancelIoEx(control input)", error));
            }
            // NOT_FOUND 只表示未找到可取消请求，不能释放内存或当成完成。
        }
        Ok(ControlWriteStatus::Pending)
    }

    /// 安全收取取消后的实际完成。参数：无。返回：清理成功或原取消／完成错误；本操作可超出协作期限，业务循环只能使用非阻塞方法。
    pub(super) fn cleanup(&mut self) -> Result<(), ChildError> {
        let requested = self.request_close().map(|_| ());
        let mut completion_failure = None;
        while self.pending {
            if let Err(error) = self.finish_io(true)
                && completion_failure.is_none()
            {
                // 异常查询的重复失败不累积错误链；保留第一项真实完成错误。
                completion_failure = Some(error);
            }
            if self.pending {
                // bWait=TRUE 正常会等到完成；异常查询仍不能释放活跃内存，也不紧循环。
                std::thread::sleep(Duration::from_millis(1));
            }
        }
        self.write.take();
        let completion = completion_failure.map_or(Ok(()), Err);
        match requested {
            Err(primary) => Err(primary.with_cleanup(completion)),
            Ok(()) => completion,
        }
    }

    /// 借用真实 pending 写所使用的句柄和稳定内存。参数：无。返回：仅测试可见的原始地址，不复制或改变 operation。
    #[cfg(test)]
    pub(super) fn io_witness(&self) -> Result<(HANDLE, *const OVERLAPPED, *const u8), ChildError> {
        if !self.pending {
            return Err(ChildError::Unsupported(
                "no actual pending control operation",
            ));
        }
        Ok((self.handle()?, self.operation.as_ref(), self.bytes.as_ptr()))
    }

    /// 借用父端句柄供真实继承断言。参数：无。返回：父写端和父 event，不转移所有权。
    #[cfg(test)]
    pub(super) fn handles(&self) -> Result<(HANDLE, HANDLE), ChildError> {
        Ok((self.handle()?, self.event.as_raw()))
    }

    fn create<E>(
        name: &[u16],
        security: &PipeSecurity,
        checkpoint: &mut impl FnMut() -> Result<(), E>,
    ) -> Result<(Self, OwnedHandle), ChildSpawnError<E>> {
        let write = OwnedHandle::from_raw(
            unsafe {
                CreateNamedPipeW(
                    name.as_ptr(),
                    PIPE_ACCESS_OUTBOUND | FILE_FLAG_OVERLAPPED | FILE_FLAG_FIRST_PIPE_INSTANCE,
                    PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS,
                    1,
                    ControlWriteStatus::MAX_CHUNK_BYTES as u32,
                    ControlWriteStatus::MAX_CHUNK_BYTES as u32,
                    0,
                    &security.attributes(false),
                )
            },
            "CreateNamedPipeW(control input)",
        )?;
        let mut attributes = security.attributes(true);
        attributes.lpSecurityDescriptor = null_mut();
        let reader = OwnedHandle::from_raw(
            unsafe {
                CreateFileW(
                    name.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    &attributes,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL,
                    null_mut(),
                )
            },
            "CreateFileW(control stdin)",
        )?;
        let event = OwnedHandle::from_raw(
            unsafe { CreateEventW(null(), 1, 0, null()) },
            "CreateEventW(control input)",
        )?;
        let mut operation = Box::new(OVERLAPPED::default());
        operation.hEvent = event.as_raw();
        let mut channel = Self {
            write: Some(write),
            event,
            operation,
            bytes: Box::new([0; ControlWriteStatus::MAX_CHUNK_BYTES]),
            length: 0,
            pending: false,
            connecting: true,
            closing: false,
            cancel_requested: false,
            cancel_accepted: false,
        };
        let connected = unsafe { ConnectNamedPipe(channel.handle()?, channel.operation.as_mut()) };
        let error = if connected == 0 {
            unsafe { GetLastError() }
        } else {
            0
        };
        if connected != 0 || error == ERROR_PIPE_CONNECTED {
            channel.connecting = false;
            return Ok((channel, reader));
        }
        if error != ERROR_IO_PENDING {
            return Err(os_error("ConnectNamedPipe(control input)", error).into());
        }
        channel.pending = true;
        loop {
            if let Err(primary) = checkpoint() {
                drop(reader);
                return Err(ChildSpawnError::checkpoint(primary).with_cleanup(channel.cleanup()));
            }
            match channel.finish_io(false) {
                Ok(ControlWriteStatus::Pending) => std::thread::sleep(Duration::from_millis(1)),
                Ok(ControlWriteStatus::Written(_)) => return Ok((channel, reader)),
                Ok(ControlWriteStatus::Closed) => {
                    return Err(ChildError::Unsupported("control connect closed").into());
                }
                Err(primary) => {
                    drop(reader);
                    return Err(primary.with_cleanup(channel.cleanup()).into());
                }
            }
        }
    }

    fn handle(&self) -> Result<HANDLE, ChildError> {
        self.write
            .as_ref()
            .map(OwnedHandle::as_raw)
            .ok_or(ChildError::Unsupported(
                "control write handle already closed",
            ))
    }

    fn finish_io(&mut self, wait: bool) -> Result<ControlWriteStatus, ChildError> {
        let mut transferred = 0;
        let completed = unsafe {
            GetOverlappedResult(
                self.handle()?,
                self.operation.as_ref(),
                &mut transferred,
                i32::from(wait),
            )
        };
        let error = if completed == 0 {
            unsafe { GetLastError() }
        } else {
            0
        };
        if completed == 0 && error == ERROR_IO_INCOMPLETE {
            return Ok(ControlWriteStatus::Pending);
        }
        // 等同 Win32 HasOverlappedIoCompleted：查询失败也不能释放仍标记 STATUS_PENDING 的内存。
        if completed == 0
            && unsafe { std::ptr::read_volatile(&self.operation.Internal) }
                == STATUS_PENDING as usize
        {
            return Err(os_error("GetOverlappedResult(control still active)", error));
        }
        let connecting = self.connecting;
        self.connecting = false;
        self.pending = false;
        let length = std::mem::take(&mut self.length);
        if self.closing {
            self.write.take();
        }
        if completed == 0 {
            if error == ERROR_OPERATION_ABORTED && self.closing && self.cancel_accepted {
                return Ok(ControlWriteStatus::Closed);
            }
            return Err(os_error("GetOverlappedResult(control input)", error));
        }
        if connecting {
            // ConnectNamedPipe 的 transferred 未定义，绝不用于写入游标。
            return Ok(ControlWriteStatus::Written(0));
        }
        if transferred == 0 {
            return Err(ChildError::io(
                "GetOverlappedResult(control input)",
                io::Error::new(
                    io::ErrorKind::WriteZero,
                    "nonempty control write completed with zero bytes",
                ),
            ));
        }
        if transferred as usize > length {
            return Err(ChildError::Unsupported(
                "control completion exceeds owned chunk",
            ));
        }
        Ok(ControlWriteStatus::Written(transferred as usize))
    }
}

impl Drop for OverlappedControlPipe {
    fn drop(&mut self) {
        // 仅安全退场可等待；原业务 poll/connect 不使用 INFINITE 或 bWait=TRUE。
        let _ = self.cleanup();
    }
}

fn os_error(context: &'static str, code: u32) -> ChildError {
    ChildError::io(context, io::Error::from_raw_os_error(code as i32))
}

fn last(context: &'static str) -> ChildError {
    ChildError::io(context, io::Error::last_os_error())
}
