//! Win32 Job、启动属性与双管道的共用真实所有权。

mod attribute_list;
mod overlapped_control_pipe;
mod overlapped_pipe;
mod owned_handle;
mod pipe_security;
mod windows_child;
mod windows_command_line;
mod windows_normal_exit;

#[cfg(test)]
mod windows_control_fixture;
#[cfg(test)]
mod windows_control_input_tests;
#[cfg(test)]
mod windows_control_spawn_record;
#[cfg(test)]
mod windows_control_test_witness;
#[cfg(test)]
mod windows_normal_exit_fixture;
#[cfg(test)]
mod windows_normal_exit_test_support;
#[cfg(test)]
mod windows_normal_exit_tests;

#[cfg(test)]
pub(crate) use owned_handle::OwnedHandle;
pub(crate) use windows_child::WindowsChild;
