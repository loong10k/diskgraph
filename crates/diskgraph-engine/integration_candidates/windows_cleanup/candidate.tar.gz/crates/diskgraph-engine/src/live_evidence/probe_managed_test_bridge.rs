//! 真实旧执行器的RED桥；只绑定受管理宿主，不替换出生/清理或伪造恢复成功。
use super::ProbeLimits;
use super::probe_budget::ProbeBudget;
use super::probe_execution::run_probe;
use crate::ProbeHost;
use std::process::Command;
use std::sync::Arc;

/// 测试受管理请求走当前真实run_probe；错误只投影已有诊断，panic原值不捕获。
pub(crate) fn run_managed_probe_for_test(
    command: &mut Command,
    limits: &ProbeLimits,
    host: &ProbeHost,
) -> Result<(), String> {
    let mut budget = ProbeBudget::new(limits).map_err(|error| error.to_string())?;
    budget.bind_probe_host(Arc::clone(&host.registry));
    run_probe(command, &mut budget)
        .map(|_| ())
        .map_err(|error| error.to_string())
}
