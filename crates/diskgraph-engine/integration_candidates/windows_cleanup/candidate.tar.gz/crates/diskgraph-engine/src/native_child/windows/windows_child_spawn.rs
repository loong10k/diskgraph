//! Windows唯一出生实现；新入口使用调用方catch外槽，兼容入口保留旧清理行为。
#[cfg(test)]
use super::super::windows_control_test_witness::WindowsControlTestWitness;
use super::super::{
    attribute_list::AttributeList, overlapped_control_pipe::OverlappedControlPipe,
    overlapped_pipe::OverlappedPipe, owned_handle::OwnedHandle, pipe_security::PipeSecurity,
    windows_command_line::WindowsCommandLine, windows_normal_exit::WindowsNormalExit,
};
use super::{WindowsChild, last};
use crate::native_child::{ChildError, ChildInputMode, ChildSpawnError};
use std::process::Command;
use std::ptr::null;
use windows_sys::Win32::Foundation::HANDLE;
use windows_sys::Win32::System::JobObjects::{
    CreateJobObjectW, JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE, JOBOBJECT_EXTENDED_LIMIT_INFORMATION,
    JobObjectExtendedLimitInformation, SetInformationJobObject,
};
use windows_sys::Win32::System::Threading::{
    CREATE_NO_WINDOW, CREATE_SUSPENDED, CREATE_UNICODE_ENVIRONMENT, CreateProcessW,
    EXTENDED_STARTUPINFO_PRESENT, PROCESS_INFORMATION, ResumeThread, STARTF_USESTDHANDLES,
    STARTUPINFOEXW,
};

impl WindowsChild {
    /// 已弃用的受信内部兼容入口；参数为原命令与检查点，返回旧child/错误签名。
    /// 该签名不能移交失败owner；永久清理失败及panic没有外部Recovery保证，应迁移spawn_into。
    pub(crate) fn spawn<E>(
        command: &mut Command,
        checkpoint: impl FnMut() -> Result<(), E>,
    ) -> Result<Self, ChildSpawnError<E>> {
        Self::spawn_with_input(command, ChildInputMode::Null, checkpoint)
    }

    /// 已弃用的受信内部兼容入口，不得用于新扫描或作为远程授权路径。
    /// 既有WindowsProbe尚待迁移；此薄包装不修复其局部owner在失败返回时的生命周期限制。
    /// 参数：原命令、stdin模式和检查点；返回旧签名，不宣称清理失败owner可跨返回保留。
    pub(crate) fn spawn_with_input<E>(
        command: &mut Command,
        mode: ChildInputMode,
        checkpoint: impl FnMut() -> Result<(), E>,
    ) -> Result<Self, ChildSpawnError<E>> {
        let mut owner = None;
        match Self::spawn_into(command, mode, &mut owner, checkpoint) {
            Ok(()) => Ok(owner.take().expect("successful birth retains its owner")),
            Err(error) => {
                let cleanup = owner.as_mut().map_or(Ok(()), Self::cleanup);
                Err(error.with_cleanup(cleanup))
            }
        }
    }

    /// 在调用者catch外预留槽内出生，不在失败时消费、清理或丢弃原owner。
    /// 参数：owner必须为空且活得比catch更久，checkpoint借原期限/取消；返回原错误，出生后的owner由调用者处置。
    pub(crate) fn spawn_into<E>(
        command: &mut Command,
        mode: ChildInputMode,
        owner: &mut Option<Self>,
        mut checkpoint: impl FnMut() -> Result<(), E>,
    ) -> Result<(), ChildSpawnError<E>> {
        if owner.is_some() {
            return Err(ChildError::Unsupported("birth owner slot already occupied").into());
        }
        checkpoint().map_err(ChildSpawnError::checkpoint)?;
        let mut input = WindowsCommandLine::from_command(command)?;
        let security = PipeSecurity::for_current_user()?;
        let nonce = uuid::Uuid::new_v4();
        let stdout_name = super::pipe_name(&format!("diskgraph-probe-{nonce}-out"));
        let stderr_name = super::pipe_name(&format!("diskgraph-probe-{nonce}-err"));
        let (stdout, stdout_writer) = OverlappedPipe::create(&stdout_name, &security)?;
        let (stderr, stderr_writer) = OverlappedPipe::create(&stderr_name, &security)?;
        let (control, stdin) =
            OverlappedControlPipe::prepare_input(mode, &nonce, &security, &mut checkpoint)?;
        let job = OwnedHandle::from_raw(
            unsafe { CreateJobObjectW(null(), null()) },
            "CreateJobObjectW",
        )?;
        let mut limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION::default();
        limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        if unsafe {
            SetInformationJobObject(
                job.as_raw(),
                JobObjectExtendedLimitInformation,
                (&raw const limits).cast(),
                std::mem::size_of_val(&limits) as u32,
            )
        } == 0
        {
            return Err(last("SetInformationJobObject(KILL_ON_JOB_CLOSE)").into());
        }
        let mut attributes = AttributeList::new()?;
        let handles: [HANDLE; 3] = [
            stdin.as_raw(),
            stdout_writer.as_raw(),
            stderr_writer.as_raw(),
        ];
        attributes.set_jobs([job.as_raw()])?;
        attributes.set_handles(handles)?;
        let mut startup = STARTUPINFOEXW::default();
        startup.StartupInfo.cb = std::mem::size_of::<STARTUPINFOEXW>() as u32;
        startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
        startup.StartupInfo.hStdInput = handles[0];
        startup.StartupInfo.hStdOutput = handles[1];
        startup.StartupInfo.hStdError = handles[2];
        startup.lpAttributeList = attributes.as_raw();
        let mut info = PROCESS_INFORMATION::default();
        checkpoint().map_err(ChildSpawnError::checkpoint)?;
        let application = input.application();
        let arguments = input.arguments();
        let environment = input.environment();
        let directory = input.directory();
        // 可失败准备及出生前检查已完成；先装入外部槽，此后出生前没有用户回调。
        *owner = Some(Self {
            job: Some(job),
            process: None,
            stdout,
            stderr,
            control,
            normal_exit: WindowsNormalExit::new(),
            exit: None,
            cleaned: false,
        });
        if unsafe {
            CreateProcessW(
                application,
                arguments,
                null(),
                null(),
                1,
                CREATE_SUSPENDED
                    | CREATE_NO_WINDOW
                    | CREATE_UNICODE_ENVIRONMENT
                    | EXTENDED_STARTUPINFO_PRESENT,
                environment,
                directory,
                &startup.StartupInfo,
                &mut info,
            )
        } == 0
        {
            let error = last("CreateProcessW(JOB_LIST,HANDLE_LIST)");
            // CreateProcess失败没有出生进程；清除ready owner，避免假占用恢复容量。
            if let Some(mut prepared) = owner.take() {
                prepared.cleaned = true;
            }
            return Err(error.into());
        }
        // 成功的Win32调用保证有效process/thread句柄；接管无分配且无用户回调。
        // 后续所有后检、hook及Resume均借用已经位于catch外的原owner。
        let child = owner
            .as_mut()
            .expect("prepared owner remains in external slot");
        child.process = Some(OwnedHandle::from_raw(
            info.hProcess,
            "CreateProcessW(process handle)",
        )?);
        let thread = OwnedHandle::from_raw(info.hThread, "CreateProcessW(thread handle)")?;
        // Child 已有且 suspended；父本地写端必须立即关闭，避免 EOF 被自身阻止。
        drop(stdin);
        drop(stdout_writer);
        drop(stderr_writer);
        #[cfg(test)]
        super::super::windows_birth_test_hook::WindowsBirthTestHook::observe(child);
        #[cfg(test)]
        if let (Some(job), Some(process)) = (&child.job, &child.process) {
            WindowsControlTestWitness::record(job.as_raw(), process.as_raw());
        }
        #[cfg(test)]
        if command.get_envs().any(|(key, value)| {
            key.to_string_lossy()
                .eq_ignore_ascii_case("DG_WINDOWS_NATIVE_FAULT")
                && value.is_some_and(|value| value.to_string_lossy() == "post_create")
        }) {
            // 清理前释放本 owner 已完成的线程句柄，保持句柄生命周期明确。
            drop(thread);
            let error = ChildError::Unsupported("injected post-create failure");
            return Err(error.into());
        }
        if let Err(error) = checkpoint() {
            drop(thread);
            return Err(ChildSpawnError::checkpoint(error));
        }
        let previous = unsafe { ResumeThread(thread.as_raw()) };
        let resume_failure = if previous == u32::MAX {
            Some(last("ResumeThread"))
        } else if previous != 1 {
            Some(ChildError::Unsupported(
                "probe thread did not have exactly one suspend count",
            ))
        } else {
            None
        };
        drop(thread);
        if let Some(error) = resume_failure {
            return Err(error.into());
        }
        if let Err(error) = checkpoint() {
            return Err(ChildSpawnError::checkpoint(error));
        }
        Ok(())
    }
}
