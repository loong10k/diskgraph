import pathlib,subprocess,os,time,json,hashlib,sys
root=pathlib.Path('C:/Users/hnxyh/AppData/Local/Temp/diskgraph-desktop-jetfdyj0/reader_configuration_budget')
root.mkdir(exist_ok=True)
env=dict(os.environ,CARGO_TARGET_DIR='E:/workspaces/workspace-loong10k/diskgraph/target/desktop-1ac266a0',CARGO_BUILD_JOBS='4',RUSTFLAGS='-Dwarnings')
args=['cargo','+1.99.0','test','--locked','-p','diskgraph-store','--lib','--target','x86_64-pc-windows-msvc','reader_admission_tests','--','--nocapture']
start=time.monotonic()
with (root/'red.stdout').open('wb') as out,(root/'red.stderr').open('wb') as err:
 result=subprocess.run(args,env=env,stdout=out,stderr=err)
paths=['crates/diskgraph-store/src/sqlite_snapshot_store.rs','crates/diskgraph-store/src/reader_admission_tests.rs']
receipt={'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'argv':args,'elapsed_seconds':time.monotonic()-start,'exit_code':result.returncode,'hashes':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths}}
(root/'red.receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt),flush=True)
print((root/'red.stdout').read_text(encoding='utf-8',errors='replace')[-8000:],flush=True)
print((root/'red.stderr').read_text(encoding='utf-8',errors='replace')[-4000:],flush=True)
sys.exit(result.returncode)
