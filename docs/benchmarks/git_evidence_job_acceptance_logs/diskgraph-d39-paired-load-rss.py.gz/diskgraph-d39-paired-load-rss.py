import subprocess,sys,re,runpy,json,pathlib,os
original_run=subprocess.run
observations=[]
def measured_run(command,*args,**kwargs):
    target=isinstance(command,(list,tuple)) and command and pathlib.Path(str(command[0])).name=='diskgraph'
    actual=['/usr/bin/time','-l',*map(str,command)] if target else command
    result=original_run(actual,*args,**kwargs)
    if target:
        match=re.search(r'(\d+)\s+maximum resident set size',result.stderr or '')
        if not match: raise RuntimeError('macOS time omitted child RSS')
        observations.append({'returncode':result.returncode,'max_rss_bytes':int(match.group(1))})
    return result
subprocess.run=measured_run
try:runpy.run_path(os.environ['DISKGRAPH_LOAD_SCRIPT'],run_name='__main__')
finally:
    pathlib.Path(os.environ['DISKGRAPH_LOAD_RSS_OUTPUT']).write_text(json.dumps({'measurement':'macOS time -l individual CLI child maximum RSS, not simultaneous total RSS','children':len(observations),'maximum_individual_child_rss_bytes':max((x['max_rss_bytes'] for x in observations),default=None),'observations':observations},indent=2)+'\n')
