import ctypes,hashlib,json,os,pathlib,shutil,subprocess,time
r=json.loads(pathlib.Path('/private/tmp/diskgraph-d39-verified-candidate.json').read_text());snapshot=pathlib.Path(r['snapshot'])
source=pathlib.Path('/private/tmp/diskgraph-d24-validation-target/release');binary=pathlib.Path('/private/tmp/diskgraph-d39-candidate-release-bin');binary.mkdir(exist_ok=True)
for name in ['diskgraph','diskgraph-mcp','libdiskgraph_ffi.dylib']:shutil.copy2(source/name,binary/name)
record={'source_snapshot':str(snapshot),'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.iterdir() if p.is_file()}}
pathlib.Path('/private/tmp/diskgraph-d39-release-binaries.json').write_text(json.dumps(record,indent=2)+'\n')
results=[]
for name in ['stdio','http']:
 command=['python3',str(snapshot/f'scripts/accept-readonly-{name}.py')];log=pathlib.Path(f'/private/tmp/diskgraph-d39-release-{name}.log')
 with log.open('w') as stream:result=subprocess.run(command,cwd=snapshot,env={**os.environ,'DISKGRAPH_ACCEPT_BIN_DIR':str(binary)},stdout=stream,stderr=subprocess.STDOUT,timeout=180)
 results.append({'name':name,'command':command,'exit_code':result.returncode,'log':str(log)})
 print(json.dumps(results[-1]),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
baseline=json.loads(pathlib.Path('/private/tmp/diskgraph-d37-release-uniffi.json').read_text())['actual'];library=ctypes.CDLL(str(binary/'libdiskgraph_ffi.dylib'));actual={}
for name in baseline:
 function=getattr(library,name);function.restype=ctypes.c_uint16;actual[name]=function()
mismatches={name:{'expected':baseline[name],'actual':actual[name]} for name in baseline if baseline[name]!=actual[name]}
pathlib.Path('/private/tmp/diskgraph-d39-release-uniffi.json').write_text(json.dumps({'total':len(baseline),'passed':len(baseline)-len(mismatches),'actual':actual,'mismatches':mismatches},indent=2)+'\n')
assert not mismatches,mismatches
for size in [20000,200000]:
 command=['python3','/private/tmp/diskgraph-d39-paired-load-rss.py','--bin-dir',str(binary),'--files',str(size),'--output',f'/private/tmp/diskgraph-d39-candidate-load{size}.json'];log=pathlib.Path(f'/private/tmp/diskgraph-d39-candidate-load{size}.log')
 environment={**os.environ,'DISKGRAPH_LOAD_SCRIPT':str(snapshot/'scripts/accept-readonly-load.py'),'DISKGRAPH_LOAD_RSS_OUTPUT':f'/private/tmp/diskgraph-d39-candidate-load{size}-rss.json'}
 with log.open('w') as stream:result=subprocess.run(command,cwd=snapshot,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
 results.append({'name':f'load{size}','command':command,'exit_code':result.returncode,'log':str(log)})
 print(json.dumps(results[-1]),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
pathlib.Path('/private/tmp/diskgraph-d39-release-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('release acceptance, 19 ABI checks, and paired 20k/200k load complete',flush=True)
