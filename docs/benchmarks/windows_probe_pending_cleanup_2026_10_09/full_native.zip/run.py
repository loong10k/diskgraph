import sys
sys.stdout.reconfigure(encoding='utf-8',errors='backslashreplace')
import subprocess,os,time,pathlib,json,hashlib,sys
p=pathlib.Path(r'C:\Users\hnxyh\AppData\Local\Temp\diskgraph-desktop-jetfdyj0\pending_probe_full_parallel');p.mkdir(exist_ok=True)
e=dict(os.environ,CARGO_TARGET_DIR=r'E:\workspaces\workspace-loong10k\diskgraph\target\desktop-1ac266a0',CARGO_BUILD_JOBS='4',RUSTFLAGS='-Dwarnings')

binding_root=pathlib.Path(r'C:\Users\hnxyh\AppData\Local\Temp\diskgraph-desktop-jetfdyj0\parallel_observation_release')
for line in (binding_root/'acceptance.env').read_text(encoding='utf-8-sig').splitlines():
 if '=' in line:
  k,v=line.split('=',1);e[k]=v
worker=pathlib.Path(e['DISKGRAPH_SCAN_WORKER_PATH'])
assert hashlib.sha256(worker.read_bytes()).hexdigest().lower()==e['DISKGRAPH_SCAN_WORKER_SHA256'].lower()
assert worker.stat().st_size==int(e['DISKGRAPH_SCAN_WORKER_BYTES'])
driver=pathlib.Path(r'E:\workspaces\workspace-loong10k\diskgraph\target\desktop-1ac266a0\debug\examples\scan_worker_driver_fixture.exe')
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='938b2fb44f624f70255825a51359e9450df67bddb199c6b136e22c7e207f8d4c'
e['DISKGRAPH_SCAN_DRIVER_FIXTURE']=str(driver)

commands=[('engine_default_parallel',['test','--locked','-p','diskgraph-engine','--lib','--target','x86_64-pc-windows-msvc','--','--nocapture'])]

receipt={'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_hashes':{x:hashlib.sha256(pathlib.Path(x).read_bytes()).hexdigest() for x in ['crates/diskgraph-engine/src/live_evidence/windows_probe_execution.rs','crates/diskgraph-engine/src/native_child/windows/windows_cleanup_hooks.rs','crates/diskgraph-engine/src/native_child/windows/windows_probe_recovery_tests.rs','crates/diskgraph-engine/src/lib.rs','crates/diskgraph-engine/src/scan_execution.rs','crates/diskgraph-engine/src/scan_observation_batch.rs','crates/diskgraph-engine/src/windows_scan_observation.rs','crates/diskgraph-engine/src/live_evidence/git_stash_location.rs','crates/diskgraph-engine/src/live_evidence/git_stash.rs','crates/diskgraph-engine/src/live_evidence/git_reference_verification_tests.rs','crates/diskgraph-engine/src/live_evidence/git_references.rs','crates/diskgraph-engine/src/live_evidence/git_divergence.rs','crates/diskgraph-engine/src/live_evidence/git_usage.rs','crates/diskgraph-engine/src/live_evidence/mod.rs','crates/diskgraph-engine/src/live_evidence/git_semantics_tests.rs','crates/diskgraph-engine/src/git_evidence_execution_tests.rs']},'commands':[]}
for name,args in commands:
 t=time.monotonic();a=['cargo','+1.99.0',*args]
 with (p/(name+'.stdout.log')).open('wb') as o,(p/(name+'.stderr.log')).open('wb') as z:r=subprocess.run(a,env=e,stdout=o,stderr=z,timeout=900)
 receipt['commands'].append({'name':name,'argv':a,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-t})
 (p/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 print(name,r.returncode,flush=True);print((p/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace')[-5000:],flush=True);print((p/(name+'.stderr.log')).read_text(encoding='utf-8',errors='replace')[-2200:],flush=True)

print(json.dumps(receipt))

sys.exit(1 if any(c['exit_code'] for c in receipt['commands']) else 0)
