import importlib.util
import pathlib
import subprocess
import sys
import json
import re
import threading

root = pathlib.Path.cwd()
release = pathlib.Path("/private/tmp/diskgraph-d24-validation-target/release")
cli = release / "diskgraph"
original_run = subprocess.run
observations = []
lock = threading.Lock()

def measured_run(args, *positional, **keywords):
    if args and pathlib.Path(args[0]) == cli:
        result = original_run(["/usr/bin/time", "-l", *args], *positional, **keywords)
        match = re.search(r"(\d+)\s+maximum resident set size", result.stderr or "")
        if match is None:
            raise RuntimeError("missing macOS per-CLI-child peak RSS")
        with lock:
            observations.append({"peak_rss_bytes": int(match.group(1)), "arguments": [str(x) for x in args[1:]]})
        return result
    return original_run(args, *positional, **keywords)

subprocess.run = measured_run
spec = importlib.util.spec_from_file_location("load", root / "scripts/accept-readonly-load.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
files = int(sys.argv[1])
output = pathlib.Path(f"/private/tmp/diskgraph-d33-load-{files}.json")
sys.argv = ["accept-readonly-load.py", "--bin-dir", str(release), "--files", str(files), "--output", str(output)]
result = module.main()
report = json.loads(output.read_text())
report["per_cli_child_peak_rss_bytes"] = max(x["peak_rss_bytes"] for x in observations)
report["rss_observed_cli_children"] = len(observations)
report["rss_method"] = "macOS /usr/bin/time -l on each actual CLI process, bytes; child maximum, not aggregate concurrent RSS"
output.write_text(json.dumps(report, indent=2) + "\n")
pathlib.Path(f"/private/tmp/diskgraph-d33-load-{files}-rss.json").write_text(json.dumps(observations, indent=2) + "\n")
print(json.dumps({"files":files,"peak_cli_child_rss_bytes": report["per_cli_child_peak_rss_bytes"]}),flush=True)
raise SystemExit(result)
