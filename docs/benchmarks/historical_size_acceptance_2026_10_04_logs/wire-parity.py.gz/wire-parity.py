import pathlib
import tempfile
import subprocess
import json

bin_dir = pathlib.Path("/private/tmp/diskgraph-d24-validation-target/release")
with tempfile.TemporaryDirectory(prefix="diskgraph-d33-wire-") as directory:
    work = pathlib.Path(directory)
    root, data = work / "root", work / "data"
    root.mkdir()
    item = root / "item"
    item.write_bytes(b"known payload")

    def cli(*arguments):
        result = subprocess.run([bin_dir / "diskgraph", "--data-dir", data, "--json", *arguments], capture_output=True, text=True, timeout=60, check=True)
        return json.loads(result.stdout.splitlines()[-1])

    scope = cli("scope", "add", "--root", root)["data"]["scope_id"]
    before = cli("index", "--scope", scope, "--wait")["data"]["revision_id"]
    item.unlink()
    item.mkdir()
    (item / "child").write_bytes(b"different directory contents")
    after = cli("sync", "--scope", scope, "--wait")["data"]["revision_id"]
    growth = cli("growth", "--scope", scope, "--before", before, "--after", after, "--path", "item")
    changes = cli("changes", "--scope", scope, "--before", before, "--after", after)
    messages = [
        {"jsonrpc":"2.0", "id":1, "method":"initialize", "params":{"protocolVersion":"2025-06-18", "capabilities":{}, "clientInfo":{"name":"d33-history-parity", "version":"1"}}},
        {"jsonrpc":"2.0", "method":"notifications/initialized"},
        {"jsonrpc":"2.0", "id":2, "method":"tools/call", "params":{"name":"diskgraph_changes", "arguments":{"scope":scope, "before":before, "after":after}}}
    ]
    process = subprocess.run([bin_dir / "diskgraph-mcp", "--data-dir", data], input="".join(json.dumps(m)+"\n" for m in messages), capture_output=True, text=True, timeout=60, check=True)
    responses = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
    answer = next(x for x in responses if x.get("id") == 2)
    assert "error" not in answer, answer
    content = answer["result"]["structuredContent"]
    assert not answer["result"].get("isError", False), answer
    assert growth["ok"] and growth["data"]["comparable"] is False and growth["data"]["delta_bytes"] is None, growth
    assert changes["ok"] and changes["data"]["size_changed"] == 0 and changes["data"]["added"] == 1, changes
    assert content["ok"] and content["data"] == changes["data"], content
    report = {"passed":3,"total":3,"checks":{"cli_type_replacement_refuses_numeric_growth":True,"cli_type_replacement_not_size_change":True,"mcp_actual_changes_matches_cli":True},"cli_growth":growth,"cli_changes":changes,"mcp_response":answer}
    pathlib.Path("/private/tmp/diskgraph-d33-wire-parity.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
