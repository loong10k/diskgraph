import sys,hashlib,tarfile
from pathlib import Path
sys.path.insert(0,'/input')
from qualify_linux_supervisor_birth import qualify
archive=Path('/input/archive.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='d4d800eb39fbd20e450b76847a8865d77ed965dab42a52fca56b77642746557b'
prefix=Path('/opt/current-birth-images'); prefix.mkdir(mode=0o755)
with tarfile.open(archive) as package:
    for name in ('diskgraph','diskgraph-scan-worker'):
        member=package.getmember('diskgraph-aarch64-unknown-linux-gnu/bin/'+name)
        image=prefix/name; image.write_bytes(package.extractfile(member).read()); image.chmod(0o555)
qualify(prefix/'diskgraph',prefix/'diskgraph-scan-worker',Path('/out/native_green.json'))
