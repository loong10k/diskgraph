use diskgraph_engine::{Engine, EngineConfig, EngineError};
use std::sync::Arc;
/// 仅历史基线的原Engine入口；来源：该冻结提交的原公开API，不用于候选资格。
pub(crate) struct BenchmarkEngine { pub(crate) engine: Arc<Engine> }
impl BenchmarkEngine {
    /// 参数：原基线配置；返回：原行为引擎，不增加worker或替换历史扫描路径。
    pub(crate) fn open(config: EngineConfig) -> Result<Self, EngineError> {
        Ok(Self { engine: Arc::new(Engine::open(config)?) })
    }
}
