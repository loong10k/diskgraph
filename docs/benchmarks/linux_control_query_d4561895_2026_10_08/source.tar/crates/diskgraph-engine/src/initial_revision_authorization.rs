//! 初始授权的控制锁、SQL 与能力回调期限边界。
use crate::authority_expiry::check_authority_expiry;
use crate::{Engine, EngineError};
use diskgraph_core::{Authorizer, BusinessError, Permission, PrincipalId, ScopeId};

impl Engine {
    // 初始授权只使用原请求期限；控制锁和控制 SQL 不另建宽限窗口。
    /// 沿原请求期限检查持久归属、实时权限与能力交集。
    /// 参数：ownership 是图查询的真实归属，expected_scope 为一致性断言，身份与期限不可刷新。
    /// 返回：实际 scope；已观察拒权优先，迟到允许及控制预算耗尽拒绝。
    pub(super) fn authorize_revision_owner_until(
        &self,
        revision: &str,
        ownership: Option<(String, String)>,
        expected_scope: Option<&ScopeId>,
        principal: &PrincipalId,
        authorizer: &dyn Authorizer,
        deadline: std::time::Instant,
    ) -> Result<ScopeId, EngineError> {
        let expiry = authorizer.expires_at_unix_seconds();
        check_authority_expiry(expiry)?;
        let (server, scope) = ownership.ok_or(BusinessError::PermissionDenied)?;
        let scope = ScopeId::new(scope).map_err(|_| BusinessError::PermissionDenied)?;
        let control = self.control_until(deadline)?;
        check_authority_expiry(expiry)?;
        let authorization = control.with_read_deadline(deadline, |control| {
            if server != control.existing_server_id()?.as_str()
                || expected_scope.is_some_and(|expected| expected != &scope)
            {
                return Err(EngineError::Business(BusinessError::PermissionDenied));
            }
            if control.scope_revoked(&scope)? {
                return Err(EngineError::Business(BusinessError::PermissionDenied));
            }
            let withdrawal = crate::request_withdrawal_witness::RequestWithdrawalWitness::capture(
                control, principal, &scope,
            )?;
            Ok::<_, EngineError>((withdrawal, control.authorization_generation()?))
        });
        let (withdrawal, generation) = match authorization {
            Err(EngineError::Store(error))
                if matches!(error, diskgraph_store::StoreError::BudgetExceeded)
                    || error.is_interrupted()
                    || error.is_busy() =>
            {
                return Err(BusinessError::BudgetExceeded.into());
            }
            other => other?,
        };
        drop(control);
        // 宿主回调位于控制锁和 SQLite handler 之外；回调后重新观察归属及实时授权。
        check_authority_expiry(expiry)?;
        let decision = authorizer.decide(principal, &Permission::MetadataRead, &scope);
        check_authority_expiry(expiry)?;
        if matches!(decision, diskgraph_core::Decision::Denied(_)) {
            return Err(BusinessError::PermissionDenied.into());
        }
        if std::time::Instant::now() >= deadline {
            return Err(BusinessError::BudgetExceeded.into());
        }
        let control = self.control_until(deadline)?;
        check_authority_expiry(expiry)?;
        let authorization = control.with_read_deadline(deadline, |control| {
            if server != control.existing_server_id()?.as_str() {
                return Err(EngineError::Business(BusinessError::PermissionDenied));
            }
            Self::require_decision_with_control(
                control,
                decision,
                principal,
                &Permission::MetadataRead,
                &scope,
            )?;
            if control.scope_revoked(&scope)? {
                return Err(EngineError::Business(BusinessError::PermissionDenied));
            }
            withdrawal.check(control)?;
            // 未知通知能力下，恢复后的允许不能抹去首次授权窗口里的代次变化。
            if !withdrawal.has_native_watch() && control.authorization_generation()? != generation {
                return Err(BusinessError::Conflict.into());
            }
            Ok(())
        });
        match authorization {
            Err(EngineError::Store(error))
                if matches!(error, diskgraph_store::StoreError::BudgetExceeded)
                    || error.is_interrupted()
                    || error.is_busy() =>
            {
                return Err(BusinessError::BudgetExceeded.into());
            }
            other => self.prioritize_revision_quarantine(
                other,
                &[(revision, &scope)],
                &control,
                deadline,
            )?,
        }
        if std::time::Instant::now() >= deadline {
            return Err(BusinessError::BudgetExceeded.into());
        }
        check_authority_expiry(expiry)?;
        Ok(scope)
    }
}

impl Engine {
    /// 在可信 reader 的原期限内核对能力与实时持久授权。
    /// 参数：身份与 scope 为实际归属，expiry 是锁外固定值，deadline 不得刷新。
    /// 返回：允许、明确拒权或预算失败；回调不得继承 SQLite VM handler。
    pub(super) fn require_reader_capability_until(
        &self,
        authorizer: &dyn Authorizer,
        principal: &PrincipalId,
        scope: &ScopeId,
        expiry: Option<u64>,
        deadline: std::time::Instant,
    ) -> Result<(), EngineError> {
        check_authority_expiry(expiry)?;
        let control = self.control_until(deadline)?;
        control
            .with_read_deadline(deadline, |control| {
                if control.scope_revoked(scope)? {
                    return Err(EngineError::Business(BusinessError::PermissionDenied));
                }
                Ok(())
            })
            .map_err(reader_control_error)?;
        drop(control);
        // 宿主能力回调不持控制锁；回调后沿原期限重新观察实时权限。
        check_authority_expiry(expiry)?;
        let decision = authorizer.decide(principal, &Permission::MetadataRead, scope);
        check_authority_expiry(expiry)?;
        if matches!(decision, diskgraph_core::Decision::Denied(_)) {
            return Err(BusinessError::PermissionDenied.into());
        }
        if std::time::Instant::now() >= deadline {
            return Err(BusinessError::BudgetExceeded.into());
        }
        let control = self.control_until(deadline)?;
        check_authority_expiry(expiry)?;
        control
            .with_read_deadline(deadline, |control| {
                Self::require_decision_with_control(
                    control,
                    decision,
                    principal,
                    &Permission::MetadataRead,
                    scope,
                )?;
                if control.scope_revoked(scope)? {
                    return Err(EngineError::Business(BusinessError::PermissionDenied));
                }
                Ok(())
            })
            .map_err(reader_control_error)?;
        check_authority_expiry(expiry)
    }
}

// 只映射查询执行期限与锁等待；其他损坏及权限错误保留原含义。
fn reader_control_error(error: EngineError) -> EngineError {
    match error {
        EngineError::Store(error)
            if matches!(error, diskgraph_store::StoreError::BudgetExceeded)
                || error.is_interrupted()
                || error.is_busy() =>
        {
            BusinessError::BudgetExceeded.into()
        }
        other => other,
    }
}
