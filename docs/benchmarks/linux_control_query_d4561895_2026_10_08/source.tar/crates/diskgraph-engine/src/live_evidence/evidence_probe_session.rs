use super::git_metadata_budget::GitMetadataBudget;
use super::git_usage::sample_git_using_budget;
use super::probe_budget::ProbeBudget;
use super::process_usage::{sample_process_usage_using_budget, unobservable};
use super::sampling_clock::now_ms;
use super::{GitSample, ProbeLimits, UsageCoverage, UsageSample};
use std::path::Path;

/// 同一多目标证据任务独占的执行与原始输入预算；不能克隆或失败后补充额度。
/// 来源：原生 Rust DiskGraph 实时证据任务设计 D29，无 Java 对应实现。
/// 这是受信库内采样接口；调用方仍须检查 scope 授权、程序来源和目标路径边界。
pub struct EvidenceProbeSession {
    budget: ProbeBudget,
    metadata: Option<GitMetadataBudget>,
    failure: Option<String>,
    allocation_quota: u64,
    min_free: u64,
}

impl EvidenceProbeSession {
    /// 从创建时固定整次任务期限、输出与取消；Git 输入累计限 64 MiB/32768 条目。
    /// 参数：limits 为既有配置，后续目标不重置期限或额度。
    /// 返回：独占会话或配置、到期、取消错误；不建立任何请求授权。
    pub fn new(limits: &ProbeLimits) -> Result<Self, String> {
        let mut budget = ProbeBudget::new(limits).map_err(|error| error.to_string())?;
        budget.check().map_err(|error| error.to_string())?;
        Ok(Self {
            budget,
            metadata: Some(GitMetadataBudget::default()),
            failure: None,
            allocation_quota: 128 << 20,
            min_free: 64 << 20,
        })
    }

    /// 参数：limits保留原预算，host为受信有限宿主；返回：绑定同一恢复责任的会话或原失败。
    /// 调用方必须在本会话及catch之外保留ProbeRecovery；不产生进程或授予访问权限。
    #[cfg(windows)]
    pub fn new_with_probe_host(
        limits: &ProbeLimits,
        host: &crate::ProbeHost,
    ) -> Result<Self, String> {
        let mut session = Self::new(limits)?;
        session
            .budget
            .bind_probe_host(std::sync::Arc::clone(&host.registry))
            .map_err(|error| error.to_string())?;
        Ok(session)
    }

    /// 参数：limits/started/cancel为原任务预算，host为Engine的同一宿主；返回：独占会话。
    /// 从原认领时间建立一次期限；绑定宿主不得延长时间或补充输出、输入额度。
    #[cfg(windows)]
    pub(crate) fn for_git_job_with_probe_host(
        limits: &diskgraph_core::GitEvidenceLimits,
        started: std::time::Instant,
        cancel: std::sync::Arc<std::sync::atomic::AtomicBool>,
        host: &crate::ProbeHost,
    ) -> Result<Self, super::git_product_error::GitProductError> {
        let mut session = Self::for_git_job(limits, started, cancel)?;
        session
            .budget
            .bind_probe_host(std::sync::Arc::clone(&host.registry))
            .map_err(|error| {
                super::git_product_error::GitProductError::from_failure(Some(&error))
            })?;
        Ok(session)
    }

    /// 从成功认领的原起点建立产品会话。参数：limits 为服务端持久配置，started 为原 Instant，cancel 为原任务标志。
    /// 返回：共享绝对期限、原始输入和实际分配限额的独占会话；不读取客户端配置。
    pub(crate) fn for_git_job(
        limits: &diskgraph_core::GitEvidenceLimits,
        started: std::time::Instant,
        cancel: std::sync::Arc<std::sync::atomic::AtomicBool>,
    ) -> Result<Self, super::git_product_error::GitProductError> {
        use super::git_product_error::GitProductError;
        let deadline = started
            .checked_add(std::time::Duration::from_millis(limits.max_duration_ms()))
            .ok_or(GitProductError::Unverifiable)?;
        let configured = ProbeLimits {
            timeout: std::time::Duration::from_millis(limits.max_duration_ms()),
            max_output_bytes: limits
                .max_output_bytes()
                .try_into()
                .map_err(|_| GitProductError::Unverifiable)?,
            cancel,
        };
        let mut budget = ProbeBudget::until(&configured, deadline)
            .map_err(|error| GitProductError::from_failure(Some(&error)))?;
        budget
            .check()
            .map_err(|error| GitProductError::from_failure(Some(&error)))?;
        let metadata = GitMetadataBudget::new(
            limits
                .max_input_bytes()
                .try_into()
                .map_err(|_| GitProductError::Unverifiable)?,
            limits
                .max_input_entries()
                .try_into()
                .map_err(|_| GitProductError::Unverifiable)?,
        )
        .map_err(|_| GitProductError::Unverifiable)?;
        Ok(Self {
            budget,
            metadata: Some(metadata),
            failure: None,
            allocation_quota: limits.max_capture_bytes(),
            min_free: limits.min_free_bytes(),
        })
    }

    /// 对固定索引身份采样；参数：工具、注册根、无损定位及已授权索引身份。
    /// 返回：完成清理及终检的样本或有界类型化失败，绝不回传 raw 工具诊断。
    pub(crate) fn sample_git_indexed(
        &mut self,
        git: &Path,
        root: &Path,
        locator: &diskgraph_core::QualifiedLocator,
        indexed: &super::git_indexed_directory::GitIndexedDirectory,
    ) -> Result<GitSample, super::git_product_error::GitProductError> {
        let result = (|| {
            self.ready()?;
            let boundary = super::git_scope_boundary::GitScopeBoundary::new_indexed(
                root,
                locator,
                indexed,
                &mut self.budget,
            )?;
            let metadata = self
                .metadata
                .take()
                .ok_or("evidence session metadata budget unavailable")?;
            let mut view = super::git_view::GitView::prepare_scoped(
                git,
                boundary,
                &mut self.budget,
                metadata,
                self.allocation_quota,
                self.min_free,
            )?;
            let observed = super::git_usage::observe(&mut view, &mut self.budget);
            view.complete_with_metadata(observed, &mut self.budget)
        })();
        match result {
            Ok((sample, metadata)) => {
                self.metadata = Some(metadata);
                Ok(sample)
            }
            Err(error) => {
                self.close(error);
                Err(super::git_product_error::GitProductError::from_failure(
                    self.budget.failure(),
                ))
            }
        }
    }

    /// 在任务剩余额度内采样下一项目，准备、复核及清理失败均关闭整次会话。
    /// 参数：git 为受信程序路径，project 为受信项目目录；本方法不解析远程授权。
    /// 返回：完成清理与终态期限检查的样本，或锁存的首次失败；不会恢复默认额度。
    pub fn sample_git(&mut self, git: &Path, project: &Path) -> Result<GitSample, String> {
        self.ready()?;
        let Some(metadata) = self.metadata.take() else {
            return Err(self.close("evidence session metadata budget unavailable".into()));
        };
        match sample_git_using_budget(
            git,
            project,
            &mut self.budget,
            metadata,
            128 << 20,
            64 << 20,
        ) {
            Ok((sample, remaining)) => {
                self.metadata = Some(remaining);
                Ok(sample)
            }
            Err(error) => Err(self.close(error)),
        }
    }

    /// 在调用方已验证的注册范围内捕获完整普通 Git 输入，再只查询私有副本。
    /// 参数：git 为可信工具，registered_root 为已授权注册根，project 为持久无损定位。
    /// 返回：共享任务预算内的完整样本或锁存错误；这是可信库入口，不执行身份授权或创建任务。
    pub fn sample_git_scoped(
        &mut self,
        git: &Path,
        registered_root: &Path,
        project: &diskgraph_core::QualifiedLocator,
    ) -> Result<GitSample, String> {
        self.ready()?;
        let result = (|| {
            let boundary = super::git_scope_boundary::GitScopeBoundary::new(
                registered_root,
                project,
                &mut self.budget,
            )?;
            let metadata = self
                .metadata
                .take()
                .ok_or("evidence session metadata budget unavailable")?;
            let mut view = super::git_view::GitView::prepare_scoped(
                git,
                boundary,
                &mut self.budget,
                metadata,
                128 << 20,
                64 << 20,
            )?;
            let observed = super::git_usage::observe(&mut view, &mut self.budget);
            view.complete_with_metadata(observed, &mut self.budget)
        })();
        match result {
            Ok((sample, metadata)) => {
                self.metadata = Some(metadata);
                Ok(sample)
            }
            Err(error) => Err(self.close(error)),
        }
    }

    /// 在同一任务预算内观察下一组路径，保留正向 partial；不可观察关闭会话。
    /// 参数：lsof 为受信程序路径，paths 为精确对象路径；空请求也先检查会话状态。
    /// 返回：既有覆盖语义的样本；首次失败后任何调用均不启动新程序。
    pub fn sample_process_usage(&mut self, lsof: &Path, paths: &[&Path]) -> UsageSample {
        if let Err(error) = self.ready() {
            return unobservable(now_ms(), error);
        }
        let sample = sample_process_usage_using_budget(lsof, paths, &mut self.budget);
        if let UsageCoverage::Unobservable { reason } = &sample.coverage {
            self.close(reason.clone());
        }
        sample
    }

    fn ready(&mut self) -> Result<(), String> {
        if let Some(error) = &self.failure {
            return Err(error.clone());
        }
        self.budget
            .check()
            .map_err(|error| self.close(error.to_string()))
    }

    fn close(&mut self, error: String) -> String {
        self.failure.get_or_insert(error).clone()
    }

    /// 读取实际余额用于跨目标累计回归。参数：无。返回：剩余输出与可重用元数据字节/条目。
    #[cfg(test)]
    pub(super) fn resources_for_test(&self) -> (usize, Option<(usize, usize)>) {
        (
            self.budget.remaining_bytes(),
            self.metadata
                .as_ref()
                .map(|metadata| (metadata.remaining_bytes(), metadata.remaining_entries())),
        )
    }

    /// 设置确定性输入额度，不补充生产会话。参数：bytes/entries 为夹具初始额度。返回：无，非法配置失败。
    #[cfg(test)]
    pub(super) fn metadata_limits_for_test(&mut self, bytes: usize, entries: usize) {
        self.metadata = Some(GitMetadataBudget::new(bytes, entries).unwrap());
    }

    /// 推进既有期限用于调用间超期回归。参数：无。返回：无，不创建新时钟或额度。
    #[cfg(test)]
    pub(super) fn expire_for_test(&mut self) {
        self.budget.expire_for_test();
    }
}
