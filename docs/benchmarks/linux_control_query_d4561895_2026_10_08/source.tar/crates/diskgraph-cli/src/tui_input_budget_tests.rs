//! 独占子进程计量真实 TUI 读取的 Rust 请求分配；来源：OpenSpec Q-08 / 13.6。
//! 不计量 SQLite C 分配、磁盘读取量或 RSS，合法观测准备发生在计量窗口之外。

use diskgraph_engine::EngineError;
use diskgraph_store::StoreError;
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

use super::test_fixture::TuiFixture;
use super::{PAGE_SIZE, load_layer};
use crate::tui_frame_reader::TuiFrameReader;

static MEASURING: AtomicBool = AtomicBool::new(false);
static REQUESTED_BYTES: AtomicUsize = AtomicUsize::new(0);

/// 原样转发 System 的测试分配器，仅独占子进程的读取窗口计费。
/// 来源：DiskGraph 原生 Rust Q-08 成本回归；无 Java 对应实现。
struct MeasuredAllocator;

// SAFETY: 布局、指针和尺寸未经修改转发 System；计数仅使用不分配内存的原子操作。
unsafe impl GlobalAlloc for MeasuredAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() && MEASURING.load(Ordering::Relaxed) {
            REQUESTED_BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        }
        pointer
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc_zeroed(layout) };
        if !pointer.is_null() && MEASURING.load(Ordering::Relaxed) {
            REQUESTED_BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        }
        pointer
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let pointer = unsafe { System.realloc(pointer, layout, size) };
        if !pointer.is_null() && MEASURING.load(Ordering::Relaxed) {
            REQUESTED_BYTES.fetch_add(size, Ordering::Relaxed);
        }
        pointer
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        unsafe { System.dealloc(pointer, layout) }
    }
}

#[global_allocator]
static ALLOCATOR: MeasuredAllocator = MeasuredAllocator;

fn measured<T>(work: impl FnOnce() -> T) -> (T, usize) {
    REQUESTED_BYTES.store(0, Ordering::Relaxed);
    MEASURING.store(true, Ordering::Relaxed);
    let result = work();
    MEASURING.store(false, Ordering::Relaxed);
    (result, REQUESTED_BYTES.load(Ordering::Relaxed))
}

fn isolated(test_name: &str, work: impl FnOnce()) {
    const CHILD: &str = "DISKGRAPH_TUI_INPUT_ALLOCATION_CHILD";
    if std::env::var(CHILD).ok().as_deref() == Some(test_name) {
        work();
        return;
    }
    // 父进程永不启用计量，子进程只执行一个真实测试，排除并发测试分配干扰。
    let output = std::process::Command::new(std::env::current_exe().unwrap())
        .args([test_name, "--exact", "--nocapture", "--test-threads=1"])
        .env(CHILD, test_name)
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    eprintln!("{stdout}");
    assert!(
        output.status.success(),
        "{stdout}\n{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(stdout.contains("test result: ok. 1 passed"));
}

fn navigation_cost(known_size: bool) {
    let fixture = TuiFixture::new(2 << 20, known_size);
    let request = fixture.request();
    let (result, allocated) = measured(|| load_layer(&request, 1));
    println!("known_size={known_size}, navigation_requested_rust_bytes={allocated}");
    assert!(
        allocated < 1 << 20,
        "a small navigation page owned unneeded metadata: {allocated} requested Rust bytes"
    );
    match result {
        Ok(layer) => {
            assert_eq!(layer.name, "root");
            assert_eq!(layer.children.len(), 1);
            assert_eq!(layer.children[0].name, "parent");
            assert_eq!(layer.children[0].size_bytes, 30);
        }
        // 超大旧 JSON 需要借用准入拒绝；不能让普通 deadline 或任意错误充数。
        Err(EngineError::Store(StoreError::BudgetExceeded)) if !known_size => {}
        other => panic!("neither a valid projection nor explicit raw admission: {other:?}"),
    }
}

fn nested_frame_cost(known_size: bool) {
    let fixture = TuiFixture::new(2 << 20, known_size);
    let mut observed = false;
    let result = fixture.engine.with_authorized_revision_reader(
        &fixture.revision,
        &fixture.principal,
        &fixture.policy,
        1000,
        |reader, snapshot, deadline| {
            // cached=0 明确不把实际节点预先缓存，也不省略嵌套 Store 路径。
            let mut reads = TuiFrameReader::new(reader, snapshot, deadline, 0, 0);
            observed = true;
            let (layer, allocated) = measured(|| reads.load_layer(2, PAGE_SIZE));
            println!("known_size={known_size}, nested_requested_rust_bytes={allocated}");
            assert!(
                allocated < 1 << 20,
                "a small nested page owned unneeded metadata: {allocated} requested Rust bytes"
            );
            match layer {
                Some(layer) => {
                    assert_eq!(layer.name, "parent");
                    assert_eq!(layer.children.len(), 2);
                    assert_eq!(layer.children[0].name, "leaf-b");
                    assert_eq!(layer.children[1].name, "leaf-a");
                    assert_eq!(layer.children[0].size_bytes, 20);
                    assert_eq!(layer.children[1].size_bytes, 10);
                    assert!(reads.take_error().is_none());
                }
                None if !known_size => {
                    let failure = reads.take_error();
                    assert!(
                        matches!(
                            reads.truncation_reason,
                            Some(
                                "byte_budget" | "byte_limit" | "raw_byte_budget" | "raw_byte_limit"
                            )
                        ) || matches!(
                            failure,
                            Some(EngineError::Store(StoreError::BudgetExceeded))
                        ),
                        "unrelated failure satisfied raw admission: {:?}, {failure:?}",
                        reads.truncation_reason
                    );
                }
                None => {
                    let failure = reads.take_error();
                    panic!(
                        "measured metadata must return its valid projection: {:?}, {failure:?}",
                        reads.truncation_reason
                    );
                }
            }
            Ok(())
        },
    );
    assert!(
        observed,
        "the real nested store path was never reached: {result:?}"
    );
    assert!(
        result.is_ok(),
        "unexpected authorization/deadline failure: {result:?}"
    );
}

#[test]
fn navigation_does_not_own_large_unneeded_measured_metadata() {
    isolated(
        "tui::input_budget_tests::navigation_does_not_own_large_unneeded_measured_metadata",
        || navigation_cost(true),
    );
}

#[test]
fn navigation_admits_large_legacy_json_before_owned_decoding() {
    isolated(
        "tui::input_budget_tests::navigation_admits_large_legacy_json_before_owned_decoding",
        || navigation_cost(false),
    );
}

#[test]
fn nested_frame_does_not_own_large_unneeded_measured_metadata() {
    isolated(
        "tui::input_budget_tests::nested_frame_does_not_own_large_unneeded_measured_metadata",
        || nested_frame_cost(true),
    );
}

#[test]
fn nested_frame_admits_large_legacy_json_before_owned_decoding() {
    isolated(
        "tui::input_budget_tests::nested_frame_admits_large_legacy_json_before_owned_decoding",
        || nested_frame_cost(false),
    );
}

// 必需 revision 目标的计量从真实 TUI 入口之前开始，不能只量已经授权后的 consumer。
fn header_navigation_cost(large: bool) {
    let mut fixture = TuiFixture::new(0, true);
    if large {
        fixture.republish_snapshot_id(&"s".repeat(2 << 20));
    }
    let request = fixture.request();
    let started = std::time::Instant::now();
    let (result, allocated) = measured(|| load_layer(&request, 1));
    let elapsed = started.elapsed();
    println!("large_header={large}, whole_navigation_rust_bytes={allocated}");
    assert!(
        allocated < 1 << 20,
        "revision preparation owned the oversized header: {allocated}"
    );
    if large {
        assert!(
            elapsed < std::time::Duration::from_millis(1000),
            "navigation raw failure arrived after its deadline"
        );
        assert!(
            matches!(
                result,
                Err(EngineError::Store(StoreError::BudgetExceeded))
                    | Err(EngineError::Business(
                        diskgraph_core::BusinessError::BudgetExceeded
                    ))
            ),
            "large required header escaped raw admission: {result:?}"
        );
    } else {
        let layer = result.unwrap();
        assert_eq!(layer.name, "root");
        assert_eq!(layer.children.len(), 1);
        assert_eq!(layer.children[0].name, "parent");
    }
}

fn header_frame_cost(large: bool) {
    header_frame_cost_with_pause(large, None);
}

fn header_frame_cost_with_pause(large: bool, pause: Option<std::time::Duration>) {
    let mut fixture = TuiFixture::new(0, true);
    let cached = load_layer(&fixture.request(), 1).unwrap();
    if large {
        // 旧缓存确实来自同一根的合法历史，不能令初始准备失败借缓存提交。
        fixture.republish_snapshot_id(&"s".repeat(2 << 20));
    }
    let request = fixture.request();
    let phase =
        super::deadline_phase_authorizer::TuiDeadlinePhaseAuthorizer::new(request.authorizer);
    if let Some(delay) = pause {
        phase.pause_first_decision(delay);
    }
    let request = crate::tui_request::TuiRequest {
        authorizer: &phase,
        ..request
    };
    let browser = super::Browser::new(&fixture.revision, cached.clone());
    let mut terminal = ratatui::Terminal::new(ratatui::backend::TestBackend::new(80, 24)).unwrap();
    let mut painted = false;
    let started = std::time::Instant::now();
    let (result, allocated) = measured(|| {
        super::draw_authorized_frame(&mut terminal, &request, &cached, |frame, reads| {
            painted = true;
            super::draw(frame, &browser, reads);
        })
    });
    let elapsed = started.elapsed();
    println!(
        "large_header={large}, whole_frame_rust_bytes={allocated}, painted={painted}, elapsed_us={}, actual={result:?}",
        elapsed.as_micros()
    );
    assert!(
        allocated < 1 << 20,
        "frame preparation owned the oversized header: {allocated}"
    );
    let actual: String = terminal
        .backend()
        .buffer()
        .content()
        .iter()
        .map(|cell| cell.symbol())
        .collect();
    if large || pause.is_some() {
        if pause.is_some() {
            assert!(
                matches!(
                    result,
                    Err(EngineError::Business(
                        diskgraph_core::BusinessError::BudgetExceeded
                    ))
                ),
                "ordinary initial authorization must expire on its original deadline: {result:?}"
            );
            assert!(
                phase.phases().0 > 0,
                "actual policy callback was not reached"
            );
        }
        assert!(
            matches!(
                result,
                Err(EngineError::Store(StoreError::BudgetExceeded))
                    | Err(EngineError::Business(
                        diskgraph_core::BusinessError::BudgetExceeded
                    ))
            ),
            "initial header failure became a displayable frame: {result:?}"
        );
        assert!(
            !painted,
            "oversized initial target reached the paint consumer"
        );
        assert!(
            actual.trim().is_empty(),
            "initial raw failure applied a backend frame"
        );
        // 上面已验证实际拒绝、零绘制和零提交；宿主调度不构成硬墙钟保证。
        // 延迟对照必须真的越过原期限，之后仍由同一公开入口拒绝普通合法头。
        if let Some(delay) = pause {
            assert!(
                elapsed >= delay,
                "the initial authorization delay was not observed"
            );
        }
    } else {
        result.unwrap();
        assert!(painted);
        assert!(
            actual.contains("parent"),
            "ordinary frame was not applied: {actual}"
        );
    }
}

#[test]
fn whole_navigation_admits_required_revision_target_before_owning_it() {
    isolated(
        "tui::input_budget_tests::whole_navigation_admits_required_revision_target_before_owning_it",
        || header_navigation_cost(true),
    );
}

#[test]
fn whole_frame_admits_required_revision_target_before_painting() {
    isolated(
        "tui::input_budget_tests::whole_frame_admits_required_revision_target_before_painting",
        || header_frame_cost(true),
    );
}

#[test]
fn ordinary_revision_target_preserves_real_navigation_and_frame() {
    isolated(
        "tui::input_budget_tests::ordinary_revision_target_preserves_real_navigation_and_frame",
        || {
            header_navigation_cost(false);
            header_frame_cost(false);
        },
    );
}

#[test]
fn initial_frame_authorization_expiry_never_applies_cached_data() {
    isolated(
        "tui::input_budget_tests::initial_frame_authorization_expiry_never_applies_cached_data",
        || header_frame_cost_with_pause(false, Some(std::time::Duration::from_millis(120))),
    );
}
