import os, subprocess, json, pathlib, sys
root=pathlib.Path('/Users/wandl/workspaces/workspace-loong10k/diskgraph')
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/diskgraph-d24-validation-target')
packages=['diskgraph-core','diskgraph-store','diskgraph-disktree','diskgraph-ffi','diskgraph-testkit','diskgraph-engine','diskgraph-cli','diskgraph-mcp','diskgraph-ops']
steps=[
 ('workspace',['cargo','test','--workspace','--all-targets','--locked','--offline','--no-fail-fast']),
 ('build',['cargo','build','--workspace','--all-targets','--locked','--offline']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--offline','--','-D','warnings']),

]
results=json.loads(pathlib.Path('/private/tmp/diskgraph-d34-quality-results.json').read_text())
for name,command in steps:
 print('starting '+name,flush=True)
 with open('/private/tmp/diskgraph-d34-'+name+'.log','w') as output:
  result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 results[name]=result.returncode
 pathlib.Path('/private/tmp/diskgraph-d34-quality-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name+' exit '+str(result.returncode),flush=True)
 if result.returncode: sys.exit(result.returncode)
