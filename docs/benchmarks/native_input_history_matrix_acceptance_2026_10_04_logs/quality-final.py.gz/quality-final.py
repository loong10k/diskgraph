import os, subprocess, json, pathlib, sys
root=pathlib.Path('/Users/wandl/workspaces/workspace-loong10k/diskgraph')
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/diskgraph-d24-validation-target')
packages=['diskgraph-core','diskgraph-store','diskgraph-disktree','diskgraph-ffi','diskgraph-testkit','diskgraph-engine','diskgraph-cli','diskgraph-mcp','diskgraph-ops']
steps=[
 ('workspace',['cargo','test','--workspace','--all-targets','--locked','--offline','--no-fail-fast']),
 ('build',['cargo','build','--workspace','--all-targets','--locked','--offline']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--offline','--','-D','warnings']),
 ('fmt',['cargo','fmt']+sum((['-p',p] for p in packages),[])+['--','--check']),
 ('include-fmt',['rustfmt','--edition','2024','--check','crates/diskgraph-ffi/src/api_exports.rs','crates/diskgraph-ffi/src/job_handle.rs']),
 ('openspec',['openspec','validate','implement-diskgraph-platform','--strict']),
 ('release',['cargo','build','--release','--locked','--offline','-p','diskgraph-cli','-p','diskgraph-mcp','-p','diskgraph-ffi']),
]
results={}
for name,command in steps:
 print('starting '+name,flush=True)
 with open('/private/tmp/diskgraph-d35-final-'+name+'.log','w') as output:
  result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 results[name]=result.returncode
 pathlib.Path('/private/tmp/diskgraph-d35-final-quality-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name+' exit '+str(result.returncode),flush=True)
 if result.returncode: sys.exit(result.returncode)
