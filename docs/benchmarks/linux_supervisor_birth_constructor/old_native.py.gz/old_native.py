import sys,hashlib,tarfile
from pathlib import Path
sys.path.insert(0,'/input')
from qualify_linux_supervisor_birth import qualify
archive=Path('/input/archive.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='750dc1c9875edcfa8c953330f29079da00dceff713325cb69ed1ee0b05dddb66'
prefix=Path('/opt/old-birth-images'); prefix.mkdir(mode=0o755)
with tarfile.open(archive) as package:
    for name in ('diskgraph','diskgraph-scan-worker'):
        member=package.getmember('diskgraph-aarch64-unknown-linux-gnu/bin/'+name)
        image=prefix/name; image.write_bytes(package.extractfile(member).read()); image.chmod(0o555)
qualify(prefix/'diskgraph',prefix/'diskgraph-scan-worker',Path('/out/old_native_red.json'))
