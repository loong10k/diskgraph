import importlib.util,os,socket,subprocess,json
from functools import partial
spec=importlib.util.spec_from_file_location('birth','/fixture/birth.py')
birth=importlib.util.module_from_spec(spec);spec.loader.exec_module(birth)
scratch=[os.open('/dev/null',os.O_RDONLY|os.O_CLOEXEC) for _ in range(8)]
a,b=socket.socketpair(socket.AF_UNIX,socket.SOCK_DGRAM)
c,d=socket.socketpair(socket.AF_UNIX,socket.SOCK_STREAM)
process=None
try:
    code='import os,socket,json; print(json.dumps({"uid":os.getuid(),"gid":os.getgid(),"groups":os.getgroups(),"material_type":socket.socket(fileno=5).getsockopt(socket.SOL_SOCKET,socket.SO_TYPE),"control_type":socket.socket(fileno=6).getsockopt(socket.SOL_SOCKET,socket.SO_TYPE)}))'
    process=subprocess.Popen(['/usr/bin/python3','-c',code],pass_fds=(b.fileno(),d.fileno(),5,6),preexec_fn=partial(birth.demote,fixed_fds=(b.fileno(),d.fileno())),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    out,err=process.communicate()
    assert process.returncode==0,err
    record=json.loads(out)
    assert record=={'uid':23111,'gid':23111,'groups':[],'material_type':socket.SOCK_DGRAM,'control_type':socket.SOCK_STREAM},record
    print(json.dumps({'passed':True,'original_child_waited':True,'observed':record}))
finally:
    if process is not None and process.poll() is None:process.wait()
    for endpoint in (a,b,c,d):endpoint.close()
    for fd in scratch:os.close(fd)
