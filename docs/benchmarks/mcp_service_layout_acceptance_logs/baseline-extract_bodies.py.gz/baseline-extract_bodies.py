"""Rust callable evidence: lexical body tokens preserve literal spelling; comments/spacing omitted."""
import hashlib, json, re, sys
from pathlib import Path

def tokens(source):
    output=[]; i=0
    while i<len(source):
        start=i
        if source[i].isspace(): i+=1; continue
        if source.startswith('//',i):
            end=source.find('\n',i); i=len(source) if end<0 else end; continue
        if source.startswith('/*',i):
            level=1; i+=2
            while level:
                if source.startswith('/*',i): level+=1; i+=2
                elif source.startswith('*/',i): level-=1; i+=2
                else: i+=1
                assert i<=len(source)
            continue
        raw=re.match(r'(?:br|cr|r)(#*)"',source[i:])
        if raw:
            end='"'+raw[1]; begin=i+raw.end(); close=source.find(end,begin)
            assert close>=0
            i=close+len(end)
        elif source[i]=='"' or source.startswith(('b"','c"'),i):
            i+=1 if source[i]=='"' else 2
            while source[i]!='"':
                i+=2 if source[i]=='\\' else 1
            i+=1
        else:
            char=re.match(r"(?:b)?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'",source[i:])
            word=re.match(r'[A-Za-z_0-9]+',source[i:])
            i+=char.end() if char else word.end() if word else 1
        output.append((source[start:i],start,i))
    return output

def extract(path):
    source=Path(path).read_text(); ts=tokens(source); records=[]
    for idx,(value,_,_) in enumerate(ts):
        if value!='fn': continue
        name=ts[idx+1][0]; begin=idx+2
        while ts[begin][0]!='{': begin+=1
        depth=1; end=begin+1
        while depth:
            if ts[end][0]=='{': depth+=1
            elif ts[end][0]=='}': depth-=1
            end+=1
        raw=source[ts[begin][1]:ts[end-1][2]]
        values=[t[0] for t in ts[begin:end]]
        records.append({'name':name,'line':source.count('\n',0,ts[idx][1])+1,
            'body':raw,'body_sha256':hashlib.sha256(raw.encode()).hexdigest(),
            'tokens':values,'token_sha256':hashlib.sha256(json.dumps(values,ensure_ascii=False).encode()).hexdigest()})
    return records
if __name__=='__main__':
    print(json.dumps({str(path):extract(path) for path in sys.argv[1:]},ensure_ascii=False,indent=2))
