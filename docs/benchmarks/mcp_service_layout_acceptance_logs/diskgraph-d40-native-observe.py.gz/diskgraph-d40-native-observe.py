import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path('/Users/wandl/workspaces/workspace-loong10k/diskgraph')
TEMP = pathlib.Path('/private/tmp')
metadata = json.loads((TEMP / 'diskgraph-d40-ci-attempt1-terminal.json').read_text())
assert metadata['headSha'] == 'fd9330e44318c15db7a9a3ea0cb34e6da2b0e81d'
assert metadata['status'] == 'completed'
inventory = json.loads((ROOT / 'docs/benchmarks/git_evidence_job_native_cases_2026_10_04.json').read_text())
authority = json.loads((ROOT / 'docs/benchmarks/durable_job_authority_native_cases_2026_10_04.json').read_text())
queries = json.loads((ROOT / 'docs/benchmarks/d36_native_case_inventory_2026_10_04.json').read_text())
mapping = {r['old_qualified']: r['actual_qualified'] for r in json.loads((TEMP / 'diskgraph-d40-mapped-test-paths.json').read_text())}
unix_source = ROOT / 'crates/diskgraph-engine/src/live_evidence/git_metadata_tests.rs'
unix_only = ['links_and_fifo_are_refused_without_blocking', 'same_bytes_with_changed_native_version_are_rejected']
for function in unix_only:
    assert re.search(r'#\[cfg\(unix\)\]\s*#\[test\]\s*fn ' + function + r'\(', unix_source.read_text())
gate_log = (TEMP / 'diskgraph-d40-gate-final.log').read_text()
gate_names = re.findall(r'^test (\S+) \.\.\. ok$', gate_log, re.M)
assert len(gate_names) == 9
report = {'run_id': 37187379023, 'attempt': 1, 'source_commit': metadata['headSha'],
          'status': metadata['status'], 'conclusion': metadata['conclusion'],
          'job_count': len(metadata['jobs']), 'passed_jobs': sum(j['conclusion'] == 'success' for j in metadata['jobs']),
          'platforms': [], 'limits': ['Whole run failed in Kotlin Intel descriptor resolution before host execution.',
                                    'Case inventory and native execution observations are separate.',
                                    'Windows excludes two reviewed cfg(unix) Git cases.']}

def observe(names, results):
    rows = []
    for name in names:
        found = results.get(name, [])
        rows.append({'qualified': name, 'results': found,
                     'status': 'passed' if found == ['ok'] else 'not_observed' if not found else 'failed_or_nonunique'})
    return {'counts': {s: sum(r['status'] == s for r in rows) for s in ['passed', 'not_observed', 'failed_or_nonunique']}, 'cases': rows}

for platform in ['windows-stable', 'windows-msrv', 'linux-arm64', 'macos-intel']:
    path = TEMP / f'diskgraph-d40-ci-{platform}.log'
    raw = path.read_bytes()
    content = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw.decode())
    start = content.index('##[group]Run cargo test --workspace --all-targets')
    end = content.find('##[group]Run ', start + len('##[group]Run '))
    assert end > start, (platform, 'missing following phase')
    phase = content[start:end]
    results = {}
    for name, result in re.findall(r'\btest (\S+) \.\.\. (ok|FAILED|ignored)[^\r\n]*', phase):
        results.setdefault(name, []).append(result)
    summaries = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', phase)
    assert summaries
    required = []
    git_rows = []
    for row in inventory['cases']:
        names = [o['qualified'] for o in row['local_observations']]
        assert len(names) == 1
        name = names[0]
        if row['source'] == 'crates/diskgraph-mcp/src/lib.rs':
            name = mapping.get(name, name)
        observed = observe([name], results)['cases'][0]
        observed.update({'source': row['source'], 'function': row['function'], 'inventory_attributes': row['attributes'],
                         'reviewed_source_cfg': 'unix' if row['function'] in unix_only else None})
        git_rows.append(observed)
        if not ('windows' in platform and row['function'] in unix_only):
            required.append(name)
    missing = [name for name in required if results.get(name) != ['ok']]
    assert not missing, (platform, missing)
    query_names = queries['query_common_all_platforms'] + queries['candidate_integration_new_common_all_platforms']
    groups = {'git_product': {'counts': {s: sum(r['status'] == s for r in git_rows) for s in ['passed', 'not_observed', 'failed_or_nonunique']}, 'cases': git_rows},
              'durable_authority': observe(authority['new_cross_platform_authority_cases'] + authority['windows_correction_cases'], results),
              'prior_query_candidate': observe(query_names, results),
              'moved_mcp_cases': observe(list(mapping.values()), results),
              'mcp_source_gate': observe(gate_names, results)}
    for group in ['durable_authority', 'prior_query_candidate', 'moved_mcp_cases', 'mcp_source_gate']:
        assert not groups[group]['counts']['not_observed'] and not groups[group]['counts']['failed_or_nonunique'], (platform, group, groups[group]['counts'])
    totals = [sum(int(row[i]) for row in summaries) for i in range(3)]
    report['platforms'].append({'platform': platform, 'log': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                               'workspace_suites': len(summaries), 'passed': totals[0], 'failed': totals[1], 'ignored': totals[2], 'groups': groups})

destination = TEMP / 'diskgraph-d40-native-observations.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'record': str(destination), 'platforms': [{'platform': p['platform'], 'workspace': [p['passed'], p['failed'], p['ignored']], 'suites': p['workspace_suites'], 'groups': {k:v['counts'] for k,v in p['groups'].items()}} for p in report['platforms']]}, indent=2))
