import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path('/Users/wandl/workspaces/workspace-loong10k/diskgraph')
TEMP = pathlib.Path('/private/tmp')
COMMIT = '3531943642e5d233f8b95cbd047167bc81899df6'
metadata = json.loads((TEMP / 'diskgraph-d41-ci-terminal.json').read_text())
assert metadata['headSha'] == COMMIT
assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
assert len(metadata['jobs']) == 22
assert all(j['conclusion'] == 'success' for j in metadata['jobs'])
manifest = json.loads((TEMP / 'diskgraph-d41-preparation-candidate.json').read_text())
source_checks = []
for path, digest in manifest.items():
    raw = subprocess.check_output(['git', 'show', f'{COMMIT}:{path}'], cwd=ROOT)
    actual = hashlib.sha256(raw).hexdigest()
    assert actual == digest, path
    source_checks.append({'path': path, 'sha256': actual})
inventory = json.loads((TEMP / 'diskgraph-d41-native-case-inventory.json').read_text())
for row in inventory['cases']:
    assert manifest[row['source']] == row['source_sha256']
prior = json.loads((ROOT / 'docs/benchmarks/d36_native_case_inventory_2026_10_04.json').read_text())
groups = {
    'd41_preparation': [r['qualified'] for r in inventory['cases']],
    'd41_new_cases': [r['qualified'] for r in inventory['cases'] if r['new_case']],
    'prior_q08': prior['query_common_all_platforms'] + prior['candidate_integration_new_common_all_platforms'],
}
assert len(groups['d41_preparation']) == 20 and len(groups['d41_new_cases']) == 14
assert len(groups['prior_q08']) == 32
report = {
    'run_id': 37190906485, 'attempt': 1, 'source_commit': COMMIT,
    'status': metadata['status'], 'conclusion': metadata['conclusion'],
    'job_count': len(metadata['jobs']), 'passed_jobs': 22,
    'verified_sources': source_checks, 'platforms': [],
    'limits': ['Overlapping case groups are not additive.',
               'Native workspace execution does not prove device, cloud provider, GUI, write, signing or production deployment gates.',
               'Requested Rust allocations do not bound RSS, SQLite C memory, physical I/O or uninterruptible kernel calls.'],
}
for platform in ['windows-stable', 'windows-msrv', 'linux-arm64', 'macos-intel']:
    path = TEMP / f'diskgraph-d41-ci-{platform}.log'
    raw = path.read_bytes()
    content = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw.decode())
    start = content.index('##[group]Run cargo test --workspace --all-targets')
    end = content.find('##[group]Run ', start + len('##[group]Run '))
    assert end > start, platform
    phase = content[start:end]
    results = {}
    for name, result in re.findall(r'\btest (\S+) \.\.\. (ok|FAILED|ignored)[^\r\n]*', phase):
        results.setdefault(name, []).append(result)
    summaries = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', phase)
    assert summaries, platform
    observations = {}
    for label, names in groups.items():
        assert len(set(names)) == len(names), label
        rows = [{'qualified': name, 'results': results.get(name, []),
                 'status': 'passed' if results.get(name) == ['ok'] else 'missing_failed_or_nonunique'} for name in names]
        failures = [r for r in rows if r['status'] != 'passed']
        assert not failures, (platform, label, failures)
        observations[label] = {'passed': len(rows), 'cases': rows}
    totals = [sum(int(row[i]) for row in summaries) for i in range(3)]
    assert totals[1] == 0, platform
    report['platforms'].append({'platform': platform, 'log': str(path),
                               'sha256': hashlib.sha256(raw).hexdigest(), 'workspace_suites': len(summaries),
                               'passed': totals[0], 'failed': totals[1], 'ignored': totals[2],
                               'groups': observations})
destination = TEMP / 'diskgraph-d41-native-observations.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'record': str(destination), 'verified_sources': len(source_checks),
                  'platforms': [{'platform': p['platform'], 'workspace': [p['passed'], p['failed'], p['ignored']],
                                 'suites': p['workspace_suites'], 'groups': {k: v['passed'] for k, v in p['groups'].items()}}
                                for p in report['platforms']]}, indent=2))
