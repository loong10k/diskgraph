import hashlib, json, os, pathlib, platform, subprocess, time

tmp = pathlib.Path('/private/tmp')
candidate = json.loads((tmp / 'diskgraph-d41-preparation-final-candidate.json').read_text())
snapshot = pathlib.Path(candidate['snapshot'])
target = pathlib.Path('/private/tmp/diskgraph-d24-validation-target')
assert not (snapshot / 'target').exists()
(snapshot / 'target').symlink_to(target, target_is_directory=True)
java_home = subprocess.check_output(['/usr/libexec/java_home', '-v', '21'], text=True).strip()
environment = {'JAVA_HOME': java_home, 'CARGO_TARGET_DIR': str(target)}
log = tmp / 'diskgraph-d41-kotlin-candidate.log'
command = ['python3', 'scripts/accept-ffi-kotlin.py']
started = time.monotonic()
with log.open('w') as output:
    result = subprocess.run(command, cwd=snapshot, env={**os.environ, **environment},
                            stdout=output, stderr=subprocess.STDOUT, timeout=660)
text = log.read_text()
record = {'snapshot': str(snapshot), 'base_commit': candidate['base_commit'],
          'reviewed_source_manifest_sha256': candidate['reviewed_source_manifest_sha256'],
          'command': command, 'cwd': str(snapshot), 'environment': environment,
          'exit_code': result.returncode, 'seconds': round(time.monotonic() - started, 3),
          'platform': platform.platform(), 'architecture': platform.machine(), 'log': str(log),
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
          'source_sha256': {name: hashlib.sha256((snapshot / name).read_bytes()).hexdigest()
                            for name in ['scripts/accept-ffi-kotlin.py', 'fixtures/ffi_kotlin_host/pom.xml',
                                         'fixtures/ffi_kotlin_host/maven-settings.xml', 'scripts/ffi-smoke-host.kt']},
          'release_sha256': {name: hashlib.sha256((target / 'release' / name).read_bytes()).hexdigest()
                             for name in ['libdiskgraph_ffi.dylib', 'uniffi-bindgen']},
          'observations': {'maven_classpath_success': 'BUILD SUCCESS' in text,
                           'native_host_session_paging_poll_v1_release_reopen':
                               'Kotlin session, paging, poll, v1, release and reopen passed' in text,
                           'native_acceptance_passed': 'Native Kotlin/JVM acceptance passed' in text},
          'limits': ['local ARM does not prove macOS Intel or other OS behavior',
                     '--errors changes diagnostics only; original CI descriptor failure root cause unknown']}
(tmp / 'diskgraph-d41-kotlin-candidate.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
