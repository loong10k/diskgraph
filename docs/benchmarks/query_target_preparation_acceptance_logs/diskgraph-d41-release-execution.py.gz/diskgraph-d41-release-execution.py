import ctypes, hashlib, json, os, pathlib, subprocess
record=json.loads(pathlib.Path('/private/tmp/diskgraph-d41-preparation-final-candidate.json').read_text())
snapshot=pathlib.Path(record['snapshot']);binary=pathlib.Path('/private/tmp/diskgraph-d41-candidate-release-bin')
sha={name:hashlib.sha256((binary/name).read_bytes()).hexdigest() for name in ['diskgraph','diskgraph-mcp','libdiskgraph_ffi.dylib']}
results=[]
for name in ['stdio','http']:
    command=['python3',str(snapshot/f'scripts/accept-readonly-{name}.py')]
    log=pathlib.Path(f'/private/tmp/diskgraph-d41-final-release-{name}.log')
    environment={'DISKGRAPH_ACCEPT_BIN_DIR':str(binary)}
    with log.open('w') as output:
        result=subprocess.run(command,cwd=snapshot,env={**os.environ,**environment},stdout=output,stderr=subprocess.STDOUT,timeout=180)
    observation=json.loads(log.read_text()) if result.returncode==0 else {'error_log':log.read_text()}
    entry={'name':name,'command':command,'cwd':str(snapshot),'environment':environment,'binary_dir':str(binary),'binary_sha256':sha,'exit_code':result.returncode,'log':str(log),'observation':observation}
    results.append(entry)
    pathlib.Path('/private/tmp/diskgraph-d41-final-release-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in entry.items() if k not in ['binary_sha256','observation']}),flush=True)
    if result.returncode:raise SystemExit(result.returncode)
expected=json.loads(pathlib.Path('/private/tmp/diskgraph-d39-release-uniffi.json').read_text())['actual']
library=ctypes.CDLL(str(binary/'libdiskgraph_ffi.dylib'));actual={}
for name in expected:
    function=getattr(library,name);function.restype=ctypes.c_uint16;actual[name]=function()
mismatches={name:{'expected':expected[name],'actual':actual[name]} for name in expected if expected[name]!=actual[name]}
pathlib.Path('/private/tmp/diskgraph-d41-final-release-uniffi.json').write_text(json.dumps({'total':len(actual),'passed':len(actual)-len(mismatches),'binary':str(binary/'libdiskgraph_ffi.dylib'),'binary_sha256':sha['libdiskgraph_ffi.dylib'],'actual':actual,'mismatches':mismatches},indent=2)+'\n')
assert not mismatches,mismatches
assert all(hashlib.sha256((binary/name).read_bytes()).hexdigest()==digest for name,digest in sha.items())
print('same frozen release binaries: protocol18/18, HTTP13/13, actual UniFFI19/19',flush=True)
