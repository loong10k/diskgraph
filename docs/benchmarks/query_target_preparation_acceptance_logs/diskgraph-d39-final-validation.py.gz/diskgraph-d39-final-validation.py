import json,os,pathlib,re,subprocess,sys,time
snapshot=pathlib.Path(sys.argv[1]); prefix=pathlib.Path(sys.argv[2]); results=[]
crates=['diskgraph-core','diskgraph-store','diskgraph-disktree','diskgraph-ffi','diskgraph-testkit','diskgraph-engine','diskgraph-cli','diskgraph-mcp','diskgraph-ops']
packages=[argument for crate in crates for argument in ['-p',crate]]
commands=[
 ('workspace',['cargo','test','--workspace','--all-targets','--locked','--offline','--no-fail-fast']),
 ('fmt',['cargo','fmt',*packages,'--','--check']),
 ('ffi-include-fmt',['rustfmt','--check','--edition','2024','crates/diskgraph-ffi/src/api_exports.rs','crates/diskgraph-ffi/src/job_handle.rs']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--offline','--','-D','warnings']),
 ('build',['cargo','build','--workspace','--all-targets','--locked','--offline']),
 ('vendor',['cargo','test','--manifest-path','crates/diskgraph-disktree-core/Cargo.toml','--locked','--offline']),
 ('openspec',['openspec','validate','implement-diskgraph-platform','--strict']),
 ('release',['cargo','build','--release','--locked','--offline','-p','diskgraph-cli','-p','diskgraph-mcp','-p','diskgraph-ffi']),
]
for name,command in commands:
 log=prefix.with_name(prefix.name+'-'+name+'.log'); started=time.monotonic()
 with log.open('w') as output:
  result=subprocess.run(command,cwd=snapshot,env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/diskgraph-d24-validation-target'},stdout=output,stderr=subprocess.STDOUT)
 text=log.read_text(); observed=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 entry={'name':name,'command':command,'exit_code':result.returncode,'seconds':round(time.monotonic()-started,3),'log':str(log)}
 if observed: entry['suite_count']=len(observed); entry['passed']=sum(int(row[0]) for row in observed);entry['failed']=sum(int(row[1]) for row in observed);entry['ignored']=sum(int(row[2]) for row in observed)
 results.append(entry);prefix.with_name(prefix.name+'-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(entry),flush=True)
 if result.returncode:
  print(text[-6500:],flush=True);sys.exit(result.returncode)
