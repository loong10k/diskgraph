import pathlib,subprocess,time,json,hashlib,sys
root=pathlib.Path('C:/Users/hnxyh/AppData/Local/Temp/diskgraph-desktop-jetfdyj0/git_concurrency_isolation');root.mkdir(exist_ok=True)
exe=pathlib.Path('E:/workspaces/workspace-loong10k/diskgraph/target/desktop-1ac266a0/x86_64-pc-windows-msvc/debug/deps/diskgraph_engine-2f2e3baeae7e283c.exe')
fingerprint=hashlib.sha256(exe.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='d3fae86b16c7abfadd692e32750a1f92356102d1'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=no'],text=True).strip()
args=[str(exe),'--exact','live_evidence::tests::git_samples_dirty_stash_and_upstream_honestly','--nocapture']
processes=[];start=time.monotonic()
for index in range(8):
 out=(root/(str(index)+'.stdout')).open('wb');err=(root/(str(index)+'.stderr')).open('wb')
 process=subprocess.Popen(args,stdout=out,stderr=err)
 processes.append((index,process,out,err))
results=[]
for index,process,out,err in processes:
 code=process.wait();out.close();err.close()
 text=(root/(str(index)+'.stdout')).read_text(encoding='utf-8',errors='replace')
 errors=(root/(str(index)+'.stderr')).read_text(encoding='utf-8',errors='replace')
 results.append({'index':index,'exit_code':code,'summaries':[l for l in text.splitlines() if l.startswith('test result:')],'error_tail':errors[-1800:]})
assert hashlib.sha256(exe.read_bytes()).hexdigest()==fingerprint
receipt={'source_head':'d3fae86b16c7abfadd692e32750a1f92356102d1','binary_sha256':fingerprint,'binary_bytes':exe.stat().st_size,'concurrent_processes':8,'elapsed_seconds':time.monotonic()-start,'results':results,'production_acceptance':False,'limitations':'Eight actual native samplers in independent processes with isolated repositories; does not replace default parallel full suite or change each sample original 15s budget.'}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt),flush=True)
sys.exit(1 if any(r['exit_code'] for r in results) else 0)
