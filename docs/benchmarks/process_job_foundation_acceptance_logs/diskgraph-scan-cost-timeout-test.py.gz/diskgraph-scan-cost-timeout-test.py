"""真实派生进程超时回归；不调用 Cargo/Git，不模拟 Popen。"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("--script", type=Path, required=True)
parser.add_argument("--output-dir", type=Path, required=True)
args = parser.parse_args()
output = args.output_dir
output.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location("cost_acceptance", args.script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = {"commands": []}
grandchild = """import pathlib,sys,time
p=pathlib.Path(sys.argv[1]); n=0
while True:
    n+=1; p.write_text(str(n)); time.sleep(.02)
"""
child = """import json,os,pathlib,subprocess,sys,time
g=subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[3]])
print(json.dumps({'child_pid':os.getpid(),'grandchild_pid':g.pid}),flush=True)
p=pathlib.Path(sys.argv[2]); n=0
while True:
    n+=1; p.write_text(str(n)); time.sleep(.02)
"""
parent = """import pathlib,subprocess,sys,time
subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4]])
while not all(pathlib.Path(p).exists() for p in sys.argv[3:5]): time.sleep(.01)
print('ready: both descendants are running',flush=True)
print('real timeout stderr witness',file=sys.stderr,flush=True)
time.sleep(60)
"""
markers = [output / "child-heartbeat", output / "grandchild-heartbeat"]
pids = []
observed = {}
try:
    try:
        module.command([sys.executable, "-c", parent, child, grandchild, *map(str, markers)],
                       output, output, "timeout", report, timeout=2)
        raise AssertionError("timeout must fail the required command")
    except RuntimeError:
        pass
    stdout = (output / "timeout.stdout").read_text()
    assert "ready: both descendants are running" in stdout, "fixture did not reach descendant work"
    lineage = json.loads(stdout.splitlines()[0])
    pids = [lineage["child_pid"], lineage["grandchild_pid"]]
    before = [p.read_text() for p in markers]
    time.sleep(.25)
    after = [p.read_text() for p in markers]
    states = []
    for pid in pids:
        result = subprocess.run(["ps", "-o", "stat=", "-p", str(pid)], capture_output=True, text=True)
        states.append(result.stdout.strip())
    observed = {"before": before, "after": after, "states": states, "lineage": lineage}
    print(json.dumps(observed), flush=True)
    record = report["commands"][0]
    assert record["timed_out"] and record["exit_code"] is None
    persisted = json.loads((output / "receipt.json").read_text())["commands"][0]
    assert persisted == record
    for kind in ("stdout", "stderr"):
        raw = output / record[kind]
        assert hashlib.sha256(raw.read_bytes()).hexdigest() == record[kind + "_sha256"]
    assert before == after and all(not state or state.startswith("Z") for state in states), \
        "descendant work survived the command timeout"
    good = module.command([sys.executable, "-c", "print('success')"], output, output, "success", report)
    assert good["exit_code"] == 0 and (output / "success.stdout").read_text() == "success\n"
    bad = module.command([sys.executable, "-c", "import sys; print('failure'); sys.exit(7)"],
                         output, output, "nonzero", report, required=False)
    assert bad["exit_code"] == 7 and not bad.get("timed_out", False)
    observed["status"] = "passed"
    print("3 actual command cases passed: descendant timeout, success, nonzero", flush=True)
finally:
    # RED 版本必须也清掉自己创建的真实后代；绝不杀当前测试的共享进程组。
    for pid in pids:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    (output / "test-observations.json").write_text(json.dumps(observed, indent=2) + "\n")
