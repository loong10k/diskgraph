"""真实 SIGINT 回归：中断清理仍须保存完整 command 回执；不执行 Cargo/Git。"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

parser = argparse.ArgumentParser()
parser.add_argument("--script", type=Path, required=True)
parser.add_argument("--output-dir", type=Path, required=True)
args = parser.parse_args()
output = args.output_dir
output.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location("cost_acceptance", args.script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = {"status": "running", "commands": []}
marker = output / "heartbeat"
child = """import pathlib,sys,time
p=pathlib.Path(sys.argv[1]); n=0
while True:
    n+=1; p.write_text(str(n)); time.sleep(.02)
"""
parent = """import json,os,subprocess,sys,time
p=subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[2]])
print(json.dumps({'parent_pid':os.getpid(),'child_pid':p.pid}),flush=True)
print('actual interruption stderr',file=sys.stderr,flush=True)
time.sleep(60)
"""
sent = threading.Event()
def interrupt_when_child_works():
    until = time.monotonic() + 5
    while not marker.exists():
        if time.monotonic() >= until:
            return
        time.sleep(.01)
    sent.set()
    os.kill(os.getpid(), signal.SIGINT)
sender = threading.Thread(target=interrupt_when_child_works)
sender.start()
pids = []
observed = {}
try:
    try:
        module.command([sys.executable, "-c", parent, child, str(marker)],
                       output, output, "interrupted", report, timeout=10)
        raise AssertionError("actual SIGINT must preserve KeyboardInterrupt")
    except KeyboardInterrupt:
        assert sent.is_set()
    finally:
        sender.join()
    lineage = json.loads((output / "interrupted.stdout").read_text().splitlines()[0])
    pids = list(lineage.values())
    before = marker.read_text()
    time.sleep(.25)
    after = marker.read_text()
    states = [subprocess.run(["ps", "-o", "stat=", "-p", str(pid)], capture_output=True,
                             text=True).stdout.strip() for pid in pids]
    observed = {"lineage": lineage, "before": before, "after": after, "states": states}
    print(json.dumps(observed), flush=True)
    assert before == after and all(not state or state.startswith("Z") for state in states)
    record = report["commands"][0]
    assert record.get("aborted") is True, "interruption was not recorded as aborted"
    assert record["error"] == "KeyboardInterrupt"
    assert record["exit_code"] == record["termination_returncode"] == -signal.SIGKILL
    assert record["terminated_process_group"] is True
    assert record["elapsed_seconds"] > 0
    persisted = json.loads((output / "receipt.json").read_text())["commands"][0]
    assert persisted == record
    for kind in ("stdout", "stderr"):
        assert hashlib.sha256((output / record[kind]).read_bytes()).hexdigest() == record[kind + "_sha256"]
    observed["status"] = "passed"
    print("actual SIGINT, descendant stop, KeyboardInterrupt, complete raw/receipt: passed", flush=True)
finally:
    for pid in pids:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    (output / "test-observations.json").write_text(json.dumps(observed, indent=2) + "\n")
