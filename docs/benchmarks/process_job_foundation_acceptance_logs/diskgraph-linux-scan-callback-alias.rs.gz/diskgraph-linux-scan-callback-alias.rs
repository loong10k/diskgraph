//! std-only lifetime reproduction of the production callback bridge; no native I/O or fake backend.
use std::cell::{Cell, RefCell};
#[derive(Debug, PartialEq)]
enum Failure {
    Cancelled,
    Unsupported,
}
type NativeWork<'a, T> = dyn Fn(&dyn Fn() -> Result<(), Failure>) -> Result<T, Failure> + 'a;
fn checked_native<T>(
    check: &dyn Fn() -> Result<(), String>,
    work: &NativeWork<'_, T>,
) -> Result<Result<T, Failure>, String> {
    let original = RefCell::new(None);
    let result = work(&|| {
        if original.borrow().is_some() {
            return Err(Failure::Cancelled);
        }
        if let Err(error) = check() {
            *original.borrow_mut() = Some(error);
            return Err(Failure::Cancelled);
        }
        Ok(())
    });
    if let Some(error) = original.into_inner() {
        return Err(error);
    }
    Ok(result)
}
fn native_len(value: &str, check: &dyn Fn() -> Result<(), Failure>) -> Result<usize, Failure> {
    check()?;
    if value.is_empty() {
        return Err(Failure::Unsupported);
    }
    check()?;
    Ok(value.len())
}
fn main() {
    let borrowed = String::from("owned local path");
    let calls = Cell::new(0);
    let check = || {
        calls.set(calls.get() + 1);
        Ok(())
    };
    // Exactly the same unannotated borrowed closure call shape as LinuxScanRoot::open.
    let result = checked_native(&check, &|native_check| native_len(&borrowed, native_check));
    assert_eq!(result, Ok(Ok(borrowed.len())));
    assert_eq!(calls.get(), 2);
    let denial = String::from("original engine authority denial");
    let denied = || Err(denial.clone());
    let result = checked_native(&denied, &|native_check| native_len(&borrowed, native_check));
    assert_eq!(result, Err(denial));
    let result = checked_native(&check, &|native_check| native_len("", native_check));
    assert_eq!(result, Ok(Err(Failure::Unsupported)));
    println!("borrowed callback, original denial, native failure: verified");
}
